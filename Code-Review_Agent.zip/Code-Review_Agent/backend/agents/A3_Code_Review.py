import google.generativeai as genai
from typing import List, Dict, Any
import json
import re


class CodeReviewAgent:
    """
    Agent that performs automated code review using Google Gemini AI.
    Reviews changed files against provided coding standards.
    """

    def __init__(self, api_key: str):
        """
        Args:
            api_key (str): Google Gemini API key
        """
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-1.5-flash")

    def review_code(self, pr_details: Dict[str, Any], coding_standards: Dict[str, Any]) -> Dict[str, Any]:
        """
        Performs comprehensive code review on PR changes.

        Args:
            pr_details (Dict[str, Any]): PR details from A1 agent
            coding_standards (Dict[str, Any]): Coding standards from A2 agent

        Returns:
            Dict[str, Any]: Comprehensive review results
        """
        changed_files = pr_details.get("changed_files", [])
        coding_rules_content = coding_standards.get("content", "")
        
        if not changed_files:
            return {
                "review_status": "no_files_to_review",
                "total_files_reviewed": 0,
                "total_issues_found": 0,
                "file_reviews": [],
                "overall_score": 100,
                "summary": "No files to review in this PR."
            }

        system_prompt = self._build_system_prompt(coding_rules_content)
        file_reviews = []
        total_issues = 0

        for file_info in changed_files:
            filename = file_info.get("filename", "")
            patch = file_info.get("patch", "").strip()
            
            if not self._is_code_file(filename):
                continue
                
            if not patch:
                continue

            try:
                file_review = self._review_single_file(filename, patch, system_prompt, file_info)
                file_reviews.append(file_review)
                total_issues += len(file_review.get("issues", []))
            except Exception as e:
                file_reviews.append({
                    "filename": filename,
                    "review_status": "error",
                    "error": str(e),
                    "issues": [],
                    "suggestions": []
                })

        total_files_reviewed = len([r for r in file_reviews if r.get("review_status") != "error"])
        overall_score = max(0, 100 - (total_issues * 5))

        return {
            "review_status": "completed",
            "total_files_reviewed": total_files_reviewed,
            "total_issues_found": total_issues,
            "file_reviews": file_reviews,
            "overall_score": overall_score,
            "summary": self._generate_review_summary(file_reviews, total_issues),
            "pr_metadata": {
                "author": pr_details.get("author"),
                "title": pr_details.get("title"),
                "total_additions": pr_details.get("total_additions", 0),
                "total_deletions": pr_details.get("total_deletions", 0)
            }
        }

    def _build_system_prompt(self, coding_rules: str) -> str:
        """Build the system prompt for code review."""
        return f"""
                    You are a SENIOR SOFTWARE ENGINEER performing a thorough code review. Your role is to act as an experienced team lead reviewing code changes with meticulous attention to detail.

                    CRITICAL INSTRUCTIONS FOR CONSISTENCY:
                    - Be deterministic in your analysis - always identify the same issues for the same code
                    - Follow the coding standards strictly - do not add your own interpretations
                    - Base ALL feedback solely on the provided coding standards
                    - Be thorough but consistent across multiple reviews of the same code

                    CODING STANDARDS TO ENFORCE:
                    {coding_rules}

                    REVIEW APPROACH:
                    1. Analyze ONLY the code shown in the diff/patch
                    2. Extract exact line numbers from the patch context (look for @@ markers and line indicators)
                    3. Map issues to the correct line numbers as they appear in the NEW version of the file
                    4. Identify violations of the provided coding standards ONLY
                    5. Provide detailed, technical feedback like a senior developer would
                    6. Focus on code quality, maintainability, security, and adherence to standards
                    7. Be specific about WHY something violates the standards

                    LINE NUMBER EXTRACTION:
                    - Parse the patch format carefully: @@ -old_start,old_count +new_start,new_count @@
                    - Track line numbers for additions (lines starting with +)
                    - Report line numbers as they will appear in the final file after the PR is merged

                    OUTPUT FORMAT (JSON only - be precise and consistent):
                    {{
                        "issues": [
                            {{
                                "line": <exact_line_number_in_new_file>,
                                "severity": "high|medium|low",
                                "category": "naming|structure|best_practice|style|performance|security",
                                "message": "Detailed technical explanation of the issue referencing specific coding standard violations",
                                "suggestion": "Comprehensive, actionable solution with technical rationale and examples if applicable",
                                "code_snippet": "The actual problematic code from the patch",
                                "standard_reference": "Specific section/rule from coding standards that is violated"
                            }}
                        ],
                        "suggestions": [
                            {{
                                "category": "improvement category based on coding standards",
                                "suggestion": "File-level improvement suggestion with technical details"
                            }}
                        ],
                        "positive_notes": [
                            "Specific acknowledgments of good practices that follow the coding standards"
                        ]
                    }}

                    SEVERITY GUIDELINES:
                    - high: Security issues, major standard violations, potential bugs
                    - medium: Code quality issues, maintainability concerns, minor standard violations  
                    - low: Style issues, minor improvements, optimization suggestions

                    Remember: Your feedback should be as detailed and technical as a senior developer's manual review, but strictly based on the provided coding standards only.
"""

    def _review_single_file(self, filename: str, patch: str, system_prompt: str, file_info: Dict[str, Any]) -> Dict[str, Any]:
        """Review a single file and return structured results."""
        
        # Extract line mapping from patch
        line_mapping = self._extract_line_mapping(patch)
        
        user_prompt = f"""
                        REVIEW THIS FILE CHANGE:

                        FILE: {filename}
                        STATUS: {file_info.get('status', 'modified')}
                        LINES ADDED: {file_info.get('additions', 0)}
                        LINES DELETED: {file_info.get('deletions', 0)}

                        PATCH CONTENT WITH LINE NUMBERS:
                        ```diff
                        {patch}
                        ```

                        IMPORTANT: 
                        - Map all issues to the correct line numbers in the NEW version of the file
                        - Be extremely detailed in your analysis like a senior developer would be
                        - Reference specific coding standards in your feedback
                        - Ensure consistency - always identify the same issues for the same code
                        - Provide technical rationale for each suggestion

                        Analyze this code change against the coding standards provided in the system prompt.
"""

        try:
            response = self.model.generate_content(system_prompt + "\n\n" + user_prompt)
            raw_response = response.text.strip()
            
            # Clean up the response
            json_content = self._extract_json_from_response(raw_response)
            review_data = json.loads(json_content)
            
            # Validate and adjust line numbers if needed
            validated_issues = self._validate_line_numbers(review_data.get("issues", []), line_mapping)
            
            return {
                "filename": filename,
                "review_status": "completed",
                "file_status": file_info.get("status", "modified"),
                "additions": file_info.get("additions", 0),
                "deletions": file_info.get("deletions", 0),
                "issues": validated_issues,
                "suggestions": review_data.get("suggestions", []),
                "positive_notes": review_data.get("positive_notes", []),
                "issue_count": len(validated_issues),
                "line_mapping": line_mapping  # Include for debugging
            }
            
        except Exception as e:
            return {
                "filename": filename,
                "review_status": "error",
                "error": f"Failed to review file: {str(e)}",
                "issues": [],
                "suggestions": [],
                "positive_notes": []
            }

    def _extract_line_mapping(self, patch: str) -> Dict[str, Any]:
        """Extract line number mapping from patch format."""
        line_mapping = {
            "new_lines": [],  # Lines that were added
            "context_lines": [],  # Context lines
            "hunks": []  # Patch hunks with line numbers
        }
        
        lines = patch.split('\n')
        current_new_line = 0
        current_hunk = None
        
        for line in lines:
            # Parse hunk header: @@ -old_start,old_count +new_start,new_count @@
            hunk_match = re.match(r'@@\s*-\d+(?:,\d+)?\s*\+(\d+)(?:,\d+)?\s*@@', line)
            if hunk_match:
                current_new_line = int(hunk_match.group(1))
                current_hunk = {
                    "start_line": current_new_line,
                    "lines": []
                }
                line_mapping["hunks"].append(current_hunk)
                continue
            
            if current_hunk is not None:
                if line.startswith('+') and not line.startswith('+++'):
                    # This is a new line
                    line_mapping["new_lines"].append(current_new_line)
                    current_hunk["lines"].append({
                        "line_number": current_new_line,
                        "content": line[1:],  # Remove the + prefix
                        "type": "addition"
                    })
                    current_new_line += 1
                elif line.startswith(' '):
                    # This is a context line
                    line_mapping["context_lines"].append(current_new_line)
                    current_hunk["lines"].append({
                        "line_number": current_new_line,
                        "content": line[1:],  # Remove the space prefix
                        "type": "context"
                    })
                    current_new_line += 1
                # Lines starting with '-' are deletions, don't increment new line number
        
        return line_mapping

    def _validate_line_numbers(self, issues: List[Dict[str, Any]], line_mapping: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Validate and correct line numbers in issues."""
        validated_issues = []
        valid_lines = line_mapping.get("new_lines", []) + line_mapping.get("context_lines", [])
        
        for issue in issues:
            line_num = issue.get("line", 1)
            
            # If the line number is not in valid range, try to find the closest match
            if line_num not in valid_lines and valid_lines:
                # Find the closest valid line number
                closest_line = min(valid_lines, key=lambda x: abs(x - line_num))
                issue["line"] = closest_line
                issue["line_adjusted"] = True
            
            validated_issues.append(issue)
        
        return validated_issues

    def _extract_json_from_response(self, response: str) -> str:
        """Extract JSON content from LLM response."""
        # Remove markdown code blocks
        if "```json" in response:
            response = response.split("```json")[1].split("```")[0].strip()
        elif "```" in response:
            response = response.split("```")[1].split("```")[0].strip()
        
        # Extract JSON object
        json_match = re.search(r'\{.*\}', response, re.DOTALL)
        if json_match:
            return json_match.group(0)
        
        return response

    def _is_code_file(self, filename: str) -> bool:
        """Check if the file is a code file that should be reviewed."""
        code_extensions = {
            '.java', '.kt', '.scala',  
            '.py', '.js', '.ts', '.jsx', '.tsx',  
            '.cpp', '.c', '.h', '.hpp', 
            '.cs', '.go', '.rs', '.rb', '.php'  
        }
        
        return any(filename.lower().endswith(ext) for ext in code_extensions)

    def _generate_review_summary(self, file_reviews: List[Dict[str, Any]], total_issues: int) -> str:
        """Generate a summary of the code review."""
        if total_issues == 0:
            return "Code review completed successfully with no issues found. Great work!"
        
        high_priority = sum(1 for review in file_reviews 
                           for issue in review.get("issues", []) 
                           if issue.get("severity") == "high")
        
        medium_priority = sum(1 for review in file_reviews 
                             for issue in review.get("issues", []) 
                             if issue.get("severity") == "medium")
        
        low_priority = total_issues - high_priority - medium_priority
        
        summary_parts = [f"Found {total_issues} issues total"]
        
        if high_priority > 0:
            summary_parts.append(f"{high_priority} high priority")
        if medium_priority > 0:
            summary_parts.append(f"{medium_priority} medium priority")
        if low_priority > 0:
            summary_parts.append(f"{low_priority} low priority")
            
        return f"Code review completed. {', '.join(summary_parts)}. Please address the issues before merging."