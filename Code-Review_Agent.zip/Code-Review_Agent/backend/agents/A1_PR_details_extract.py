import requests
from typing import Dict, Any, List
import re


class RetrievePRDetailsAgent:
    """
    Agent that fetches detailed pull request information from GitHub.
    Extracts PR metadata, changed files, and diff content.
    """

    def __init__(self, github_token: str):
        """
        Args:
            github_token (str): GitHub personal access token with repo access
        """
        self.headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github.v3+json"
        }

    def extract_pr_details(self, pr_url: str) -> Dict[str, Any]:
        """
        Extract PR details from GitHub PR URL.
        
        Args:
            pr_url (str): GitHub PR URL (e.g., https://github.com/owner/repo/pull/123)
            
        Returns:
            Dict[str, Any]: Complete PR details with files and diffs
        """
        
        url_pattern = r"https://github\.com/([^/]+)/([^/]+)/pull/(\d+)"
        match = re.match(url_pattern, pr_url)
        
        if not match:
            raise ValueError(f"Invalid GitHub PR URL format: {pr_url}")
        
        repo_owner, repo_name, pr_number = match.groups()
        
        
        pr_api_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}"
        pr_response = requests.get(pr_api_url, headers=self.headers)
        
        if pr_response.status_code != 200:
            raise Exception(f"Failed to retrieve PR details: {pr_response.status_code} {pr_response.text}")
        
        pr_data = pr_response.json()
        
       
        pr_details = {
            "pr_number": int(pr_number),
            "repo_owner": repo_owner,
            "repo_name": repo_name,
            "author": pr_data.get("user", {}).get("login", "unknown"),
            "title": pr_data.get("title", ""),
            "description": pr_data.get("body", ""),
            "url": pr_data.get("html_url", ""),
            "state": pr_data.get("state", ""),
            "base_branch": pr_data.get("base", {}).get("ref", ""),
            "head_branch": pr_data.get("head", {}).get("ref", ""),
            "created_at": pr_data.get("created_at", ""),
        }
        
        
        files_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/files"
        files_response = requests.get(files_url, headers=self.headers)
        
        if files_response.status_code != 200:
            raise Exception(f"Failed to retrieve PR files: {files_response.status_code} {files_response.text}")
        
        files_data = files_response.json()
        changed_files = []
        
        for file in files_data:
            file_info = {
                "filename": file.get("filename", ""),
                "status": file.get("status", ""),  
                "additions": file.get("additions", 0),
                "deletions": file.get("deletions", 0),
                "changes": file.get("changes", 0),
                "patch": file.get("patch", "")  
            }
            changed_files.append(file_info)
        
        pr_details["changed_files"] = changed_files
        pr_details["total_files_changed"] = len(changed_files)
        pr_details["total_additions"] = sum(f["additions"] for f in changed_files)
        pr_details["total_deletions"] = sum(f["deletions"] for f in changed_files)
        
        return pr_details

    def get_pr_details_from_webhook(self, pr_payload: Dict[str, Any]) -> Dict[str, Any]:
        """
        Alternative method to process webhook payload directly.
        
        Args:
            pr_payload (Dict[str, Any]): GitHub webhook payload
            
        Returns:
            Dict[str, Any]: PR details extracted from webhook
        """
        pr_data = pr_payload.get("pull_request", {})
        pr_url = pr_data.get("html_url", "")
        
        if not pr_url:
            raise ValueError("No PR URL found in webhook payload")
        
        return self.extract_pr_details(pr_url)

