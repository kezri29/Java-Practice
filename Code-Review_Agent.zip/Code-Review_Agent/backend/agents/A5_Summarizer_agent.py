import google.generativeai as genai
from typing import Dict, Any
import json, os
import datetime


class SummarizerAgent:
    """
    Agent that creates comprehensive summaries of the entire PR review workflow.
    Provides user-friendly reports for frontend consumption.
    """

    def __init__(self, api_key: str):
        """
        Args:
            api_key (str): Google Gemini API key
        """
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')

    def generate_comprehensive_summary(self, workflow_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate a comprehensive summary of the entire PR review workflow.
        
        Args:
            workflow_data (Dict[str, Any]): Combined data from all previous agents
            
        Returns:
            Dict[str, Any]: Structured summary for frontend consumption
        """
        pr_details = workflow_data.get("pr_details", {})
        coding_standards = workflow_data.get("coding_standards", {})
        code_review_results = workflow_data.get("code_review_results", {})
        pr_comments_data = workflow_data.get("pr_comments_data", {})
        
       
        ai_summary = self._generate_ai_summary(workflow_data)
        
        
        summary = {
            "workflow_status": "completed",
            "timestamp": self._get_current_timestamp(),
            "pr_overview": {
                "title": pr_details.get("title", "Unknown PR"),
                "author": pr_details.get("author", "Unknown"),
                "pr_number": pr_details.get("pr_number"),
                "repository": f"{pr_details.get('repo_owner', '')}/{pr_details.get('repo_name', '')}",
                "url": pr_details.get("url", ""),
                "state": pr_details.get("state", "unknown"),
                "files_changed": pr_details.get("total_files_changed", 0),
                "additions": pr_details.get("total_additions", 0),
                "deletions": pr_details.get("total_deletions", 0)
            },
            "review_summary": {
                "overall_score": code_review_results.get("overall_score", 0),
                "total_issues": code_review_results.get("total_issues_found", 0),
                "files_reviewed": code_review_results.get("total_files_reviewed", 0)
            },
            "ai_narrative": ai_summary
        }
        
        return summary

    def _generate_ai_summary(self, workflow_data: Dict[str, Any]) -> str:
        """Generate AI-powered narrative summary without emojis."""
        
        system_prompt = """
                            You are a professional software development assistant. Create a comprehensive summary 
                            of a Pull Request review workflow that has been completed by automated agents.

                            The summary should be:
                            - Professional and clear
                            - Suitable for both technical and non-technical stakeholders  
                            - Highlight key findings and recommendations
                            - Provide actionable insights
                            - Be concise but comprehensive
                            - NO EMOJIS OR SPECIAL CHARACTERS - use plain text only

                            Focus on the most important aspects and provide a narrative that explains what happened 
                            during the automated review process.
                            """

        user_prompt = f"""
                            Please summarize this Pull Request review workflow:

                            PR DETAILS:
                            Author: {workflow_data.get('pr_details', {}).get('author', 'Unknown')}
                            Title: {workflow_data.get('pr_details', {}).get('title', 'No title')}
                            Files Changed: {workflow_data.get('pr_details', {}).get('total_files_changed', 0)}
                            Additions: {workflow_data.get('pr_details', {}).get('total_additions', 0)}
                            Deletions: {workflow_data.get('pr_details', {}).get('total_deletions', 0)}

                            CODING STANDARDS:
                            Source: {workflow_data.get('coding_standards', {}).get('source', 'Unknown')}
                            Repository: {workflow_data.get('coding_standards', {}).get('repository', 'N/A')}

                            CODE REVIEW RESULTS:
                            Total Issues: {workflow_data.get('code_review_results', {}).get('total_issues_found', 0)}
                            Overall Score: {workflow_data.get('code_review_results', {}).get('overall_score', 0)}/100
                            Files Reviewed: {workflow_data.get('code_review_results', {}).get('total_files_reviewed', 0)}

                            COMMENTS STATUS:
                            Existing Comments: {workflow_data.get('pr_comments_data', {}).get('existing_comments', {}).get('total_comments', 0)}

                            Create a professional summary explaining what the automated review system accomplished.
                            Use plain text only - no emojis, bullet points, or special formatting.
                            """

        try:
            response = self.model.generate_content(system_prompt + "\n\n" + user_prompt)
            summary_text = response.text.strip()
            
            
            import re
            
            summary_text = re.sub(r'[^\w\s\.\,\;\:\!\?\-\(\)]', '', summary_text)
            
            summary_text = re.sub(r'^\s*[\*\-\•]\s*', '', summary_text, flags=re.MULTILINE)
            
            return summary_text
        except Exception as e:
            return f"AI summary generation failed: {str(e)}. However, the automated review process completed successfully with the structured data available."

    def _get_current_timestamp(self) -> str:
        """Get current timestamp."""
        from datetime import datetime
        return datetime.now().isoformat()


    def _save_summary_to_markdown(self, summary: Dict[str, Any]) -> None:
        """
        Save the final summary as a uniquely named markdown (.md) file in the 'output/' directory.
        
        Args:
            summary (Dict[str, Any]): The summary data to save
        """
        output_dir = os.path.join(os.path.dirname(__file__), "output")
        os.makedirs(output_dir, exist_ok=True)

        pr_number = summary.get("pr_overview", {}).get("pr_number", "unknown")
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"summary_pr_{pr_number}_{timestamp}.md"
        filepath = os.path.join(output_dir, filename)

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                f.write("# PR Review Summary\n\n")
                f.write(f"**Title:** {summary.get('pr_overview', {}).get('title', 'N/A')}\n\n")
                f.write(f"**Author:** {summary.get('pr_overview', {}).get('author', 'N/A')}\n\n")
                f.write(f"**Repository:** {summary.get('pr_overview', {}).get('repository', 'N/A')}\n\n")
                f.write(f"**URL:** {summary.get('pr_overview', {}).get('url', '')}\n\n")
                f.write("## Review Summary\n")
                f.write(f"- Files Changed: {summary.get('pr_overview', {}).get('files_changed', 0)}\n")
                f.write(f"- Additions: {summary.get('pr_overview', {}).get('additions', 0)}\n")
                f.write(f"- Deletions: {summary.get('pr_overview', {}).get('deletions', 0)}\n")
                f.write(f"- Total Issues Found: {summary.get('review_summary', {}).get('total_issues', 0)}\n")
                f.write(f"- Overall Score: {summary.get('review_summary', {}).get('overall_score', 0)}/100\n\n")
                f.write("## AI Narrative Summary\n\n")
                f.write(summary.get("ai_narrative", "No AI summary generated."))
            print(f"📝 Summary saved to: {filepath}")
        except Exception as e:
            print(f"❌ Failed to save summary as markdown: {e}")



    def run(self, workflow_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Main execution method for the summarizer agent.
        
        Args:
            workflow_data (Dict[str, Any]): Complete workflow data from all agents
            
        Returns:
            Dict[str, Any]: Comprehensive summary ready for frontend
        """
        try:
            # return self.generate_comprehensive_summary(workflow_data)
            summary = self.generate_comprehensive_summary(workflow_data)

            # Save summary to markdown
            self._save_summary_to_markdown(summary)

            return summary
        
        except Exception as e:
            return {
                "workflow_status": "summary_error",
                "error": str(e),
                "timestamp": self._get_current_timestamp(),
                "fallback_summary": "Automated review completed but summary generation failed. Please check individual agent results."
            }