import requests
from typing import Optional, Dict, Any


class RetrieveCodingStandardsAgent:
    """
    Agent that fetches coding standards from a GitHub repository.
    Looks for coding_rules.md or similar standards files.
    """

    def __init__(self, github_token: Optional[str] = None):
        """
        Args:
            github_token (Optional[str]): GitHub token for private repos
        """
        self.github_token = github_token
        self.headers = {}
        if self.github_token:
            self.headers["Authorization"] = f"token {self.github_token}"

    def get_raw_file_contents(self, repo: str, filepath: str = "coding_rules.md", branch: str = "main") -> str:
        """
        Fetches raw file contents from GitHub repository.

        Args:
            repo (str): Repository in format 'owner/repo'
            filepath (str): Path to the coding standards file
            branch (str): Git branch to fetch from

        Returns:
            str: Raw file contents
        """
        raw_url = f"https://raw.githubusercontent.com/{repo}/{branch}/{filepath}"
        
        response = requests.get(raw_url, headers=self.headers)
        
        if response.status_code == 200:
            return response.text
        elif response.status_code == 404:
            
            alternative_files = [
                "CODING_STANDARDS.md",
                "coding_standards.md", 
                "CODE_STYLE.md",
                "code_style.md",
                "STYLE_GUIDE.md",
                "style_guide.md",
                ".github/CODING_STANDARDS.md",
                "docs/coding_rules.md",
                "docs/coding_standards.md"
            ]
            
            for alt_file in alternative_files:
                alt_url = f"https://raw.githubusercontent.com/{repo}/{branch}/{alt_file}"
                alt_response = requests.get(alt_url, headers=self.headers)
                if alt_response.status_code == 200:
                    return alt_response.text
            
            
            return self._get_default_java_standards()
        else:
            raise Exception(f"Failed to fetch coding standards: {response.status_code} - {response.text}")

    def _get_default_java_standards(self) -> str:
        """
        Returns default Java coding standards when no custom file is found.
        
        Returns:
            str: Default Java coding standards
        """
        return """
                # Default Java Coding Standards

                ## Naming Conventions
                - Class names should use PascalCase (e.g., MyClass)
                - Method names should use camelCase (e.g., myMethod)
                - Variable names should use camelCase (e.g., myVariable)
                - Constants should use UPPER_SNAKE_CASE (e.g., MAX_SIZE)
                - Package names should be lowercase (e.g., com.example.package)

                ## Code Structure
                - Use proper indentation (4 spaces or 1 tab)
                - Maximum line length of 120 characters
                - Use meaningful variable and method names
                - Add JavaDoc comments for public methods and classes
                - Avoid deep nesting (max 3-4 levels)

                ## Best Practices
                - Use try-with-resources for resource management
                - Prefer StringBuilder for string concatenation in loops
                - Use appropriate access modifiers (private, protected, public)
                - Follow single responsibility principle
                - Use proper exception handling
                - Avoid System.out.println in production code - use logging instead
                - Use Optional for nullable return types
                - Prefer composition over inheritance

                ## Code Quality
                - Remove unused imports
                - Remove dead code
                - Use meaningful comments
                - Follow consistent formatting
                - Use static analysis tools compliance
                """

    def fetch_coding_standards(self, repo: str, filepath: str = "coding_rules.md", branch: str = "main") -> Dict[str, Any]:
        """
        Main method to fetch and structure coding standards.

        Args:
            repo (str): Repository in format 'owner/repo'
            filepath (str): Path to coding standards file
            branch (str): Git branch

        Returns:
            Dict[str, Any]: Structured coding standards data
        """
        try:
            content = self.get_raw_file_contents(repo, filepath, branch)
            
            return {
                "source": "custom" if "Default Java Coding Standards" not in content else "default",
                "repository": repo,
                "filepath": filepath,
                "branch": branch,
                "content": content,
                "content_length": len(content),
                "sections": self._parse_sections(content)
            }
        except Exception as e:
            raise Exception(f"Error fetching coding standards: {str(e)}")

    def _parse_sections(self, content: str) -> Dict[str, str]:
        """
        Parse markdown content into sections.
        
        Args:
            content (str): Raw markdown content
            
        Returns:
            Dict[str, str]: Sections with titles as keys
        """
        sections = {}
        current_section = ""
        current_content = []
        
        for line in content.split('\n'):
            if line.strip().startswith('##'):
                if current_section:
                    sections[current_section] = '\n'.join(current_content).strip()
                current_section = line.strip('#').strip()
                current_content = []
            elif current_section:
                current_content.append(line)
        
        # Add the last section
        if current_section:
            sections[current_section] = '\n'.join(current_content).strip()
        
        return sections

    def run(self, repo: str, filepath: str = "coding_rules.md", branch: str = "main") -> Dict[str, Any]:
        """
        Execute the coding standards retrieval process.
        
        Args:
            repo (str): Repository identifier
            filepath (str): File path to standards
            branch (str): Git branch
            
        Returns:
            Dict[str, Any]: Complete coding standards information
        """
        return self.fetch_coding_standards(repo, filepath, branch)