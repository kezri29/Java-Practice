# import requests
# from typing import List, Dict, Any


# class PRCommentAgent:
#     """
#     Agent that posts review comments on GitHub Pull Requests and fetches existing comments.
#     """

#     def __init__(self, github_token: str):
#         """
#         Args:
#             github_token (str): GitHub personal access token
#         """
#         self.headers = {
#             "Authorization": f"token {github_token}",
#             "Accept": "application/vnd.github+json"
#         }

#     def fetch_existing_comments(self, pr_details: Dict[str, Any]) -> Dict[str, Any]:
#         """
#         Fetch existing comments and reviews from the PR.
        
#         Args:
#             pr_details (Dict[str, Any]): PR details from A1 agent
            
#         Returns:
#             Dict[str, Any]: Existing comments and reviews
#         """
#         repo_owner = pr_details.get("repo_owner")
#         repo_name = pr_details.get("repo_name")
#         pr_number = pr_details.get("pr_number")
        
#         if not all([repo_owner, repo_name, pr_number]):
#             raise ValueError("Missing required PR details for fetching comments")

        
#         comments_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/issues/{pr_number}/comments"
#         comments_response = requests.get(comments_url, headers=self.headers)
        
        
#         review_comments_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/comments"
#         review_comments_response = requests.get(review_comments_url, headers=self.headers)
        
        
#         reviews_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/reviews"
#         reviews_response = requests.get(reviews_url, headers=self.headers)
        
#         comments_data = []
#         review_comments_data = []
#         reviews_data = []
        
#         if comments_response.status_code == 200:
#             comments_data = comments_response.json()
        
#         if review_comments_response.status_code == 200:
#             review_comments_data = review_comments_response.json()
            
#         if reviews_response.status_code == 200:
#             reviews_data = reviews_response.json()

        
#         return {
#             "general_comments": self._format_general_comments(comments_data),
#             "review_comments": self._format_review_comments(review_comments_data),
#             "reviews": self._format_reviews(reviews_data),
#             "total_comments": len(comments_data) + len(review_comments_data),
#             "total_reviews": len(reviews_data),
#             "fetch_status": "success"
#         }

#     def post_review_comments(self, pr_details: Dict[str, Any], review_results: Dict[str, Any]) -> Dict[str, Any]:
#         """
#         Post automated review comments to the PR based on code review results.
        
#         Args:
#             pr_details (Dict[str, Any]): PR details from A1 agent
#             review_results (Dict[str, Any]): Review results from A3 agent
            
#         Returns:
#             Dict[str, Any]: Status of comment posting
#         """
#         repo_owner = pr_details.get("repo_owner")
#         repo_name = pr_details.get("repo_name")
#         pr_number = pr_details.get("pr_number")
        
#         if not all([repo_owner, repo_name, pr_number]):
#             raise ValueError("Missing required PR details for posting comments")

#         file_reviews = review_results.get("file_reviews", [])
        
        
#         commits_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/commits"
#         commits_response = requests.get(commits_url, headers=self.headers)
        
#         if commits_response.status_code != 200:
#             raise Exception(f"Failed to get PR commits: {commits_response.text}")
        
#         commits = commits_response.json()
#         if not commits:
#             raise Exception("No commits found in PR")
            
#         latest_sha = commits[-1]['sha']

       
#         review_comments = []
        
#         for file_review in file_reviews:
#             filename = file_review.get("filename", "")
#             issues = file_review.get("issues", [])
            
#             for issue in issues:
#                 comment_body = self._format_review_comment(issue)
                
#                 review_comments.append({
#                     "path": filename,
#                     "body": comment_body,
#                     "line": issue.get("line", 1),
#                     "side": "RIGHT"
#                 })

#         if not review_comments:
            
#             return self._post_general_review(repo_owner, repo_name, pr_number, latest_sha, review_results)

       
#         review_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/reviews"
        
#         review_body = self._create_review_body(review_results)
        
#         review_data = {
#             "commit_id": latest_sha,
#             "body": review_body,
#             "event": "COMMENT",  
#             "comments": review_comments
#         }

#         response = requests.post(review_url, headers=self.headers, json=review_data)

#         if response.status_code == 200:
#             review_data = response.json()
#             return {
#                 "post_status": "success",
#                 "review_id": review_data.get("id"),
#                 "comments_posted": len(review_comments),
#                 "review_url": review_data.get("html_url")
#             }
#         else:
#             return {
#                 "post_status": "failed",
#                 "error": f"Failed to post review: {response.status_code} - {response.text}",
#                 "comments_attempted": len(review_comments)
#             }

#     def _format_general_comments(self, comments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
#         """Format general PR comments."""
#         formatted_comments = []
#         for comment in comments:
#             formatted_comments.append({
#                 "id": comment.get("id"),
#                 "author": comment.get("user", {}).get("login", "unknown"),
#                 "body": comment.get("body", ""),
#                 "created_at": comment.get("created_at", ""),
#                 "updated_at": comment.get("updated_at", "")
#             })
#         return formatted_comments

#     def _format_review_comments(self, comments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
#         """Format inline review comments."""
#         formatted_comments = []
#         for comment in comments:
#             formatted_comments.append({
#                 "id": comment.get("id"),
#                 "author": comment.get("user", {}).get("login", "unknown"),
#                 "body": comment.get("body", ""),
#                 "path": comment.get("path", ""),
#                 "line": comment.get("line"),
#                 "created_at": comment.get("created_at", ""),
#                 "in_reply_to_id": comment.get("in_reply_to_id")
#             })
#         return formatted_comments

#     def _format_reviews(self, reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
#         """Format PR reviews."""
#         formatted_reviews = []
#         for review in reviews:
#             formatted_reviews.append({
#                 "id": review.get("id"),
#                 "author": review.get("user", {}).get("login", "unknown"),
#                 "state": review.get("state", ""),  
#                 "body": review.get("body", ""),
#                 "submitted_at": review.get("submitted_at", "")
#             })
#         return formatted_reviews

#     def _format_review_comment(self, issue: Dict[str, Any]) -> str:
#         """Format a single review issue into a comment."""
#         severity_emoji = {
#             "high": "🚨",
#             "medium": "⚠️", 
#             "low": "💡"
#         }
        
#         category_emoji = {
#             "naming": "🏷️",
#             "structure": "🏗️",
#             "best_practice": "✨",
#             "style": "🎨",
#             "performance": "⚡",
#             "security": "🔒"
#         }
        
#         severity = issue.get("severity", "medium")
#         category = issue.get("category", "general")
        
#         comment = f"{severity_emoji.get(severity, '❗')} **{severity.title()} Priority** "
#         comment += f"{category_emoji.get(category, '📝')} *{category.replace('_', ' ').title()}*\n\n"
#         comment += f"**Issue**: {issue.get('message', 'No description provided')}\n\n"
        
#         if issue.get('suggestion'):
#             comment += f"**Suggestion**: {issue.get('suggestion')}\n\n"
        
#         comment += "*Automated review by CodeReviewAgent*"
        
#         return comment

#     def _create_review_body(self, review_results: Dict[str, Any]) -> str:
#         """Create the main review body text."""
#         total_issues = review_results.get("total_issues_found", 0)
#         overall_score = review_results.get("overall_score", 0)
        
#         if total_issues == 0:
#             return "✅ **Automated Code Review Completed**\n\nGreat work! No issues found in this PR. The code follows the established coding standards."
        
#         body = f"🤖 **Automated Code Review Results**\n\n"
#         body += f"**Overall Score**: {overall_score}/100\n"
#         body += f"**Issues Found**: {total_issues}\n"
#         body += f"**Files Reviewed**: {review_results.get('total_files_reviewed', 0)}\n\n"
#         body += f"**Summary**: {review_results.get('summary', 'Review completed')}\n\n"
#         body += "Please review the inline comments below and address the identified issues."
        
#         return body

#     def _post_general_review(self, repo_owner: str, repo_name: str, pr_number: int, 
#                            commit_sha: str, review_results: Dict[str, Any]) -> Dict[str, Any]:
#         """Post a general review when no specific issues are found."""
#         review_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/reviews"
        
#         review_data = {
#             "commit_id": commit_sha,
#             "body": self._create_review_body(review_results),
#             "event": "APPROVE" if review_results.get("overall_score", 0) >= 90 else "COMMENT"
#         }

#         response = requests.post(review_url, headers=self.headers, json=review_data)

#         if response.status_code == 200:
#             review_data = response.json()
#             return {
#                 "post_status": "success",
#                 "review_id": review_data.get("id"),
#                 "comments_posted": 0,
#                 "review_url": review_data.get("html_url"),
#                 "review_type": "general_approval"
#             }
#         else:
#             return {
#                 "post_status": "failed",
#                 "error": f"Failed to post general review: {response.status_code} - {response.text}",
#                 "comments_attempted": 0
#             }

#     def run(self, pr_details: Dict[str, Any], review_results: Dict[str, Any] = None) -> Dict[str, Any]:
#         """
#         Main execution method for the PR comment agent.
        
#         Args:
#             pr_details (Dict[str, Any]): PR details from A1 agent
#             review_results (Dict[str, Any], optional): Review results from A3 agent
            
#         Returns:
#             Dict[str, Any]: Combined results of fetching and posting comments
#         """
#         results = {
#             "existing_comments": {},
#             "posted_comments": {},
#             "agent_status": "completed"
#         }
        
#         try:
            
#             existing_comments = self.fetch_existing_comments(pr_details)
#             results["existing_comments"] = existing_comments
            
            
#             if review_results:
#                 posted_comments = self.post_review_comments(pr_details, review_results)
#                 results["posted_comments"] = posted_comments
            
#             return results
            
#         except Exception as e:
#             results["agent_status"] = "error"
#             results["error"] = str(e)
#             return results


import requests
from typing import List, Dict, Any


class PRCommentAgent:
    """
    Agent that posts review comments on GitHub Pull Requests and fetches existing comments.
    """

    def __init__(self, github_token: str):
        """
        Args:
            github_token (str): GitHub personal access token
        """
        self.headers = {
            "Authorization": f"token {github_token}",
            "Accept": "application/vnd.github+json"
        }

    def fetch_existing_comments(self, pr_details: Dict[str, Any]) -> Dict[str, Any]:
        """
        Fetch existing comments and reviews from the PR.
        
        Args:
            pr_details (Dict[str, Any]): PR details from A1 agent
            
        Returns:
            Dict[str, Any]: Existing comments and reviews
        """
        repo_owner = pr_details.get("repo_owner")
        repo_name = pr_details.get("repo_name")
        pr_number = pr_details.get("pr_number")
        
        if not all([repo_owner, repo_name, pr_number]):
            raise ValueError("Missing required PR details for fetching comments")

        # Fetch general PR comments
        comments_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/issues/{pr_number}/comments"
        comments_response = requests.get(comments_url, headers=self.headers)
        
        # Fetch review comments (inline comments)
        review_comments_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/comments"
        review_comments_response = requests.get(review_comments_url, headers=self.headers)
        
        # Fetch reviews
        reviews_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/reviews"
        reviews_response = requests.get(reviews_url, headers=self.headers)
        
        comments_data = []
        review_comments_data = []
        reviews_data = []
        
        if comments_response.status_code == 200:
            comments_data = comments_response.json()
        
        if review_comments_response.status_code == 200:
            review_comments_data = review_comments_response.json()
            
        if reviews_response.status_code == 200:
            reviews_data = reviews_response.json()

        return {
            "general_comments": self._format_general_comments(comments_data),
            "review_comments": self._format_review_comments(review_comments_data),
            "reviews": self._format_reviews(reviews_data),
            "total_comments": len(comments_data) + len(review_comments_data),
            "total_reviews": len(reviews_data),
            "fetch_status": "success"
        }

    def post_review_comments(self, pr_details: Dict[str, Any], review_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Post automated review comments to the PR based on code review results.
        
        Args:
            pr_details (Dict[str, Any]): PR details from A1 agent
            review_results (Dict[str, Any]): Review results from A3 agent
            
        Returns:
            Dict[str, Any]: Status of comment posting
        """
        repo_owner = pr_details.get("repo_owner")
        repo_name = pr_details.get("repo_name")
        pr_number = pr_details.get("pr_number")
        
        if not all([repo_owner, repo_name, pr_number]):
            raise ValueError("Missing required PR details for posting comments")

        file_reviews = review_results.get("file_reviews", [])
        
        # Get the latest commit SHA
        commits_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/commits"
        commits_response = requests.get(commits_url, headers=self.headers)
        
        if commits_response.status_code != 200:
            raise Exception(f"Failed to get PR commits: {commits_response.text}")
        
        commits = commits_response.json()
        if not commits:
            raise Exception("No commits found in PR")
            
        latest_sha = commits[-1]['sha']

        # Prepare review comments with enhanced formatting
        review_comments = []
        
        for file_review in file_reviews:
            filename = file_review.get("filename", "")
            issues = file_review.get("issues", [])
            
            for issue in issues:
                comment_body = self._format_detailed_review_comment(issue, filename)
                
                review_comments.append({
                    "path": filename,
                    "body": comment_body,
                    "line": issue.get("line", 1),
                    "side": "RIGHT"
                })

        if not review_comments:
            # Post general review if no specific issues
            return self._post_general_review(repo_owner, repo_name, pr_number, latest_sha, review_results)

        # Create and post the review
        review_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/reviews"
        
        review_body = self._create_detailed_review_body(review_results)
        
        review_data = {
            "commit_id": latest_sha,
            "body": review_body,
            "event": "COMMENT",  
            "comments": review_comments
        }

        response = requests.post(review_url, headers=self.headers, json=review_data)

        if response.status_code == 200:
            review_data = response.json()
            return {
                "post_status": "success",
                "review_id": review_data.get("id"),
                "comments_posted": len(review_comments),
                "review_url": review_data.get("html_url")
            }
        else:
            return {
                "post_status": "failed",
                "error": f"Failed to post review: {response.status_code} - {response.text}",
                "comments_attempted": len(review_comments)
            }

    def _format_general_comments(self, comments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Format general PR comments."""
        formatted_comments = []
        for comment in comments:
            formatted_comments.append({
                "id": comment.get("id"),
                "author": comment.get("user", {}).get("login", "unknown"),
                "body": comment.get("body", ""),
                "created_at": comment.get("created_at", ""),
                "updated_at": comment.get("updated_at", "")
            })
        return formatted_comments

    def _format_review_comments(self, comments: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Format inline review comments."""
        formatted_comments = []
        for comment in comments:
            formatted_comments.append({
                "id": comment.get("id"),
                "author": comment.get("user", {}).get("login", "unknown"),
                "body": comment.get("body", ""),
                "path": comment.get("path", ""),
                "line": comment.get("line"),
                "created_at": comment.get("created_at", ""),
                "in_reply_to_id": comment.get("in_reply_to_id")
            })
        return formatted_comments

    def _format_reviews(self, reviews: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Format PR reviews."""
        formatted_reviews = []
        for review in reviews:
            formatted_reviews.append({
                "id": review.get("id"),
                "author": review.get("user", {}).get("login", "unknown"),
                "state": review.get("state", ""),  
                "body": review.get("body", ""),
                "submitted_at": review.get("submitted_at", "")
            })
        return formatted_reviews

    def _format_detailed_review_comment(self, issue: Dict[str, Any], filename: str) -> str:
        """Format a single review issue into a detailed comment like a senior developer would write."""
        severity_emoji = {
            "high": "🚨",
            "medium": "⚠️", 
            "low": "💡"
        }
        
        category_emoji = {
            "naming": "🏷️",
            "structure": "🏗️",
            "best_practice": "✨",
            "style": "🎨",
            "performance": "⚡",
            "security": "🔒"
        }
        
        severity = issue.get("severity", "medium")
        category = issue.get("category", "general")
        line_num = issue.get("line", "Unknown")
        
        # Enhanced comment formatting
        comment = f"{severity_emoji.get(severity, '❗')} **{severity.upper()} PRIORITY** "
        comment += f"{category_emoji.get(category, '📝')} *{category.replace('_', ' ').title()} Issue*\n\n"
        
        # File and line information
        comment += f"**📁 File:** `{filename}`\n"
        comment += f"**📍 Line:** {line_num}\n\n"
        
        # Code snippet if available
        if issue.get('code_snippet'):
            comment += f"**Code in question:**\n```\n{issue.get('code_snippet')}\n```\n\n"
        
        # Detailed issue description
        comment += f"**🔍 Issue Analysis:**\n{issue.get('message', 'No description provided')}\n\n"
        
        # Technical suggestion
        if issue.get('suggestion'):
            comment += f"**💡 Recommended Solution:**\n{issue.get('suggestion')}\n\n"
        
        # Reference to coding standard
        if issue.get('standard_reference'):
            comment += f"**📋 Coding Standard Reference:**\n{issue.get('standard_reference')}\n\n"
        
        # Line adjustment notice
        if issue.get('line_adjusted'):
            comment += f"*Note: Line number was adjusted for accuracy based on patch analysis.*\n\n"
        
        comment += "---\n*🤖 Automated review by Senior Code Review Agent*"
        
        return comment

    def _create_detailed_review_body(self, review_results: Dict[str, Any]) -> str:
        """Create the main review body text with detailed analysis."""
        total_issues = review_results.get("total_issues_found", 0)
        overall_score = review_results.get("overall_score", 0)
        total_files = review_results.get("total_files_reviewed", 0)
        
        if total_issues == 0:
            return """✅ **Senior Code Review - APPROVED**

                        🎉 **Excellent work!** This PR has passed the automated code review with no issues identified.

                        **Review Summary:**
                        - All code follows the established coding standards
                        - No violations or improvements needed
                        - Ready for merge

                        *Automated review by Senior Code Review Agent*"""
        
        # Calculate issue breakdown
        file_reviews = review_results.get("file_reviews", [])
        high_priority = sum(1 for review in file_reviews 
                           for issue in review.get("issues", []) 
                           if issue.get("severity") == "high")
        
        medium_priority = sum(1 for review in file_reviews 
                             for issue in review.get("issues", []) 
                             if issue.get("severity") == "medium")
        
        low_priority = total_issues - high_priority - medium_priority
        
        # Determine review status
        if high_priority > 0:
            status_emoji = "🚫"
            status_text = "CHANGES REQUESTED"
        elif medium_priority > 3:
            status_emoji = "⚠️"
            status_text = "REVIEW REQUIRED"
        else:
            status_emoji = "📋"
            status_text = "MINOR IMPROVEMENTS"
        
        body = f"{status_emoji} **Senior Code Review - {status_text}**\n\n"
        
        # Review metrics
        body += f"**📊 Review Metrics:**\n"
        body += f"- **Overall Score:** {overall_score}/100\n"
        body += f"- **Files Reviewed:** {total_files}\n"
        body += f"- **Total Issues:** {total_issues}\n\n"
        
        # Issue breakdown
        body += f"**🎯 Issue Breakdown:**\n"
        if high_priority > 0:
            body += f"- 🚨 **High Priority:** {high_priority} (Must fix before merge)\n"
        if medium_priority > 0:
            body += f"- ⚠️ **Medium Priority:** {medium_priority} (Should fix before merge)\n"
        if low_priority > 0:
            body += f"- 💡 **Low Priority:** {low_priority} (Consider fixing)\n"
        
        body += f"\n**📝 Summary:** {review_results.get('summary', 'Review completed')}\n\n"
        
        # Action items
        if high_priority > 0:
            body += "**⚡ Action Required:**\nHigh priority issues must be addressed before this PR can be merged.\n\n"
        elif medium_priority > 0:
            body += "**📋 Recommendations:**\nMedium priority issues should be reviewed and addressed.\n\n"
        
        body += "**👀 Next Steps:**\n"
        body += "1. Review the inline comments below\n"
        body += "2. Address the identified issues\n"
        body += "3. Push updates to trigger a new review\n\n"
        
        body += "---\n*🤖 Automated review by Senior Code Review Agent based on established coding standards*"
        
        return body

    def _post_general_review(self, repo_owner: str, repo_name: str, pr_number: int, 
                           commit_sha: str, review_results: Dict[str, Any]) -> Dict[str, Any]:
        """Post a general review when no specific issues are found."""
        review_url = f"https://api.github.com/repos/{repo_owner}/{repo_name}/pulls/{pr_number}/reviews"
        
        review_data = {
            "commit_id": commit_sha,
            "body": self._create_detailed_review_body(review_results),
            "event": "APPROVE" if review_results.get("overall_score", 0) >= 90 else "COMMENT"
        }

        response = requests.post(review_url, headers=self.headers, json=review_data)

        if response.status_code == 200:
            review_data = response.json()
            return {
                "post_status": "success",
                "review_id": review_data.get("id"),
                "comments_posted": 0,
                "review_url": review_data.get("html_url"),
                "review_type": "general_approval"
            }
        else:
            return {
                "post_status": "failed",
                "error": f"Failed to post general review: {response.status_code} - {response.text}",
                "comments_attempted": 0
            }

    def run(self, pr_details: Dict[str, Any], review_results: Dict[str, Any] = None) -> Dict[str, Any]:
        """
        Main execution method for the PR comment agent.
        
        Args:
            pr_details (Dict[str, Any]): PR details from A1 agent
            review_results (Dict[str, Any], optional): Review results from A3 agent
            
        Returns:
            Dict[str, Any]: Combined results of fetching and posting comments
        """
        results = {
            "existing_comments": {},
            "posted_comments": {},
            "agent_status": "completed"
        }
        
        try:
            # Fetch existing comments
            existing_comments = self.fetch_existing_comments(pr_details)
            results["existing_comments"] = existing_comments
            
            # Post review comments if review results are provided
            if review_results:
                posted_comments = self.post_review_comments(pr_details, review_results)
                results["posted_comments"] = posted_comments
            
            return results
            
        except Exception as e:
            results["agent_status"] = "error"
            results["error"] = str(e)
            return results