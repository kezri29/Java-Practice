# import os
# from dotenv import load_dotenv

# load_dotenv()

# class Config:
#     # Post gress config
#     SECRET_KEY = os.environ.get('SECRET_KEY', 'supersecretkey')
#     SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
#     SQLALCHEMY_TRACK_MODIFICATIONS = False

# config/config.py

import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from dotenv import load_dotenv

load_dotenv()

# Replace with your actual DB URL (can be MySQL, PostgreSQL, SQLite, etc.)
DATABASE_URL = os.environ.get('DATABASE_URL')  # For local SQLite DB

# SQLAlchemy engine
engine = create_engine(DATABASE_URL)  

# Session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Base class for models
Base = declarative_base()
