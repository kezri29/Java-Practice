# # init_db.py

# from app import app, db
# from models import model  # Ensure model.py is imported to register Job

# with app.app_context():
#     db.create_all()
#     print("✅ Database tables created successfully.")

# init_db.py

from config.config import Base, engine
from models.model import Job

Base.metadata.create_all(bind=engine)
