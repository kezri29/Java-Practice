# from flask import Flask, request, jsonify, send_file
# from flask_cors import CORS
# import os
# import threading
# import json
# from datetime import datetime
# from typing import Dict, Any
# import logging
# import time
# from pathlib import Path

# # Config
# from config.config import Config

# # DB extension
# from extensions.extension import db

# # Agent Graph
# from graph import process_pr_workflow

# # Models
# from models.model import Job

# # Logger setup
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

# # Flask App
# app = Flask(__name__)
# app.config.from_object(Config)
# db.init_app(app)
# CORS(app)

# import time

# # In-memory workflow trackers
# workflow_results = {}
# workflow_status = {}
# workflow_logs = {}

# def run_workflow_async(workflow_id: str, pr_url: str = None, pr_payload: Dict[str, Any] = None, config: Dict[str, Any] = None):
#     """
#     Run the workflow asynchronously in a separate thread.
#     """
#     try:
#         logger.info(f"🚀 Starting async workflow {workflow_id}")
#         workflow_logs[workflow_id] = []

#         workflow_status[workflow_id] = {
#             "status": "running",
#             "started_at": datetime.now().isoformat(),
#             "message": "Workflow execution in progress",
#             "progress": 0
#         }

#         workflow_logs[workflow_id].append({
#             "timestamp": datetime.now().isoformat(),
#             "level": "INFO",
#             "message": f"Workflow {workflow_id} started"
#         })

#         result = process_pr_workflow(pr_url=pr_url, pr_payload=pr_payload, config=config)

#         workflow_results[workflow_id] = result
#         workflow_status[workflow_id] = {
#             "status": "completed",
#             "started_at": workflow_status[workflow_id]["started_at"],
#             "completed_at": datetime.now().isoformat(),
#             "message": "Workflow completed successfully",
#             "progress": 100
#         }

#         workflow_logs[workflow_id].append({
#             "timestamp": datetime.now().isoformat(),
#             "level": "SUCCESS",
#             "message": f"Workflow {workflow_id} completed successfully"
#         })

#         logger.info(f"✅ Workflow {workflow_id} completed successfully")

#     except Exception as e:
#         error_msg = f"Workflow {workflow_id} failed: {str(e)}"
#         logger.error(error_msg)

#         if workflow_id in workflow_logs:
#             workflow_logs[workflow_id].append({
#                 "timestamp": datetime.now().isoformat(),
#                 "level": "ERROR",
#                 "message": error_msg
#             })

#         workflow_status[workflow_id] = {
#             "status": "failed",
#             "started_at": workflow_status[workflow_id].get("started_at"),
#             "completed_at": datetime.now().isoformat(),
#             "message": error_msg,
#             "error": str(e),
#             "progress": -1
#         }

# # ===== NEW API ROUTES FOR FRONTEND =====

# @app.route('/api/jobs', methods=['GET'])
# def get_all_jobs():
#     """
#     Get all PR jobs from the database
#     """
#     try:
#         jobs = Job.query.order_by(Job.created_at.desc()).all()
#         jobs_data = []
        
#         for job in jobs:
#             job_data = {
#                 'id': job.id,
#                 'pr_title': job.pr_title,
#                 'pr_author': job.pr_author,
#                 'pr_url': job.pr_url,
#                 'pr_number': job.pr_number,
#                 'workflow_id': job.workflow_id,
#                 'status': job.status,
#                 'created_at': job.created_at.isoformat()
#             }
#             jobs_data.append(job_data)
        
#         return jsonify({
#             'status': 'success',
#             'jobs': jobs_data,
#             'count': len(jobs_data)
#         }), 200
        
#     except Exception as e:
#         logger.error(f"❌ Error fetching jobs: {str(e)}")
#         return jsonify({
#             'error': 'Failed to fetch jobs',
#             'message': str(e)
#         }), 500

# @app.route('/api/jobs/<workflow_id>', methods=['DELETE'])
# def delete_job(workflow_id):
#     """
#     Delete a specific job by workflow_id
#     """
#     try:
#         job = Job.query.filter_by(workflow_id=workflow_id).first()
        
#         if not job:
#             return jsonify({
#                 'error': 'Job not found',
#                 'message': f'No job found with workflow_id: {workflow_id}'
#             }), 404
        
#         # Delete the job from database
#         db.session.delete(job)
#         db.session.commit()
        
#         # Also clean up any related files if they exist
#         try:
#             output_dir = Path("/agents/outputs")
#             summary_files = list(output_dir.glob(f"summary_pr_{job.pr_number}_*.md"))
#             for file in summary_files:
#                 if file.exists():
#                     file.unlink()
#                     logger.info(f"🗑️ Deleted summary file: {file}")
#         except Exception as file_error:
#             logger.warning(f"⚠️ Could not delete summary files: {file_error}")
        
#         logger.info(f"🗑️ Job {workflow_id} deleted successfully")
        
#         return jsonify({
#             'status': 'success',
#             'message': f'Job {workflow_id} deleted successfully'
#         }), 200
        
#     except Exception as e:
#         logger.error(f"❌ Error deleting job {workflow_id}: {str(e)}")
#         return jsonify({
#             'error': 'Failed to delete job',
#             'message': str(e)
#         }), 500

# @app.route('/api/jobs/<workflow_id>/summary', methods=['GET'])
# def get_job_summary(workflow_id):
#     """
#     Get the summary markdown file for a specific job
#     """
#     try:
#         job = Job.query.filter_by(workflow_id=workflow_id).first()
        
#         if not job:
#             return jsonify({
#                 'error': 'Job not found',
#                 'message': f'No job found with workflow_id: {workflow_id}'
#             }), 404
        
#         # Look for summary file in outputs directory
#         output_dir = Path(__file__).parent / "agents" / "output"
#         summary_files = list(output_dir.glob(f"summary_pr_{job.pr_number}_*.md"))
        
#         if not summary_files:
#             return jsonify({
#                 'error': 'Summary not found',
#                 'message': f'No summary file found for PR #{job.pr_number}'
#             }), 404
        
#         # Get the most recent summary file (if multiple exist)
#         summary_file = max(summary_files, key=os.path.getctime)
        
#         # Read the markdown content
#         with open(summary_file, 'r', encoding='utf-8') as f:
#             content = f.read()
        
#         return jsonify({
#             'status': 'success',
#             'workflow_id': workflow_id,
#             'pr_number': job.pr_number,
#             'summary': content,
#             'file_path': str(summary_file)
#         }), 200
        
#     except Exception as e:
#         logger.error(f"❌ Error fetching summary for {workflow_id}: {str(e)}")
#         return jsonify({
#             'error': 'Failed to fetch summary',
#             'message': str(e)
#         }), 500

# @app.route('/api/jobs/status', methods=['GET'])
# def get_jobs_status():
#     """
#     Get current status of all jobs (for real-time updates)
#     """
#     try:
#         jobs = Job.query.all()
#         status_data = {}
        
#         for job in jobs:
#             status_data[job.workflow_id] = {
#                 'id': job.id,
#                 'status': job.status,
#                 'pr_title': job.pr_title,
#                 'workflow_id': job.workflow_id
#             }
        
#         return jsonify({
#             'status': 'success',
#             'jobs_status': status_data
#         }), 200
        
#     except Exception as e:
#         logger.error(f"❌ Error fetching jobs status: {str(e)}")
#         return jsonify({
#             'error': 'Failed to fetch jobs status',
#             'message': str(e)
#         }), 500

# # ===== EXISTING ROUTES =====

# @app.route('/github-webhook', methods=['POST'])
# def handle_github_webhook():
#     """
#     Handle GitHub webhook for PR events.
#     Stores PR data into the database as a new job.
#     """
#     try:
#         if not request.is_json:
#             return jsonify({"error": "Request must be JSON"}), 400

#         data = request.get_json()
#         action = data.get("action")
#         pr_data = data.get("pull_request")

#         logger.info(f"📨 Received GitHub webhook: action={action}")

#         if action in ["opened", "synchronize"] and pr_data:
#             pr_title = pr_data.get("title", "Untitled PR")
#             pr_author = pr_data.get("user", {}).get("login", "Unknown author")
#             pr_url = pr_data.get("html_url", "")
#             pr_number = pr_data.get("number")

#             logger.info(f"🔍 Processing PR: {pr_title} by {pr_author}")

#             workflow_id = f"webhook_{pr_number}_{int(datetime.now().timestamp())}"

#             # ✅ Store PR into jobs table
#             new_job = Job(
#                 pr_title=pr_title,
#                 pr_author=pr_author,
#                 pr_url=pr_url,
#                 pr_number=pr_number,
#                 workflow_id=workflow_id,
#                 status="pending"
#             )

#             db.session.add(new_job)
#             db.session.commit()
#             logger.info(f"🗃️ Job {workflow_id} saved to database.")

#             return jsonify({
#                 "status": "accepted",
#                 "message": f"PR saved to job queue: {pr_title}",
#                 "workflow_id": workflow_id,
#                 "pr_url": pr_url,
#                 "pr_number": pr_number,
#                 "pr_author": pr_author
#             }), 202

#         else:
#             return jsonify({
#                 "status": "ignored",
#                 "message": f"Event action '{action}' not processed",
#                 "supported_actions": ["opened", "synchronize"]
#             }), 200

#     except Exception as e:
#         logger.error(f"❌ Webhook processing error: {str(e)}")
#         return jsonify({
#             "error": "Webhook processing failed",
#             "message": str(e)
#         }), 500

# def start_job_watcher():
#     """
#     Background thread that continuously watches for pending jobs
#     and processes them one by one.
#     """
#     def watch():
#         while True:
#             try:
#                 with app.app_context():
#                     # Get the first pending job only to enforce FIFO strictly
#                     job = Job.query.filter_by(status="pending").order_by(Job.created_at.asc()).first()

#                     if job:
#                         workflow_id = job.workflow_id
#                         pr_url = job.pr_url

#                         logger.info(f"👀 Detected pending job: {workflow_id}, starting processing")

#                         # ✅ Mark the job as in-progress BEFORE starting thread
#                         job.status = "in_progress"
#                         db.session.commit()

#                         config = {
#                             "post_comments": True,
#                             "skip_standards_fetch": False,
#                             "workflow_type": "webhook"
#                         }

#                         def run_and_update(workflow_id, pr_url):
#                             with app.app_context():
#                                 try:
#                                     # Re-fetch the job inside app context
#                                     job = Job.query.filter_by(workflow_id=workflow_id).first()
#                                     if job is None:
#                                         logger.error(f"⚠️ Job with workflow_id {workflow_id} not found")
#                                         return

#                                     job.status = "in_progress"
#                                     db.session.commit()

#                                     run_workflow_async(workflow_id, pr_url, None, config={ 
#                                         "post_comments": True,
#                                         "skip_standards_fetch": False,
#                                         "workflow_type": "webhook"
#                                     })

#                                     # Re-fetch again to ensure it's still valid
#                                     job = Job.query.filter_by(workflow_id=workflow_id).first()
#                                     if job:
#                                         job.status = "completed"
#                                         db.session.commit()

#                                 except Exception as e:
#                                     logger.error(f"❌ Error processing job {workflow_id}: {e}")
#                                     job = Job.query.filter_by(workflow_id=workflow_id).first()
#                                     if job:
#                                         job.status = "failed"
#                                         db.session.commit()

#                         thread = threading.Thread(target=run_and_update, args=(workflow_id, pr_url))
#                         thread.daemon = True
#                         thread.start()

#                         # Optional: wait before checking again (avoids race)
#                         time.sleep(3)

#                     else:
#                         # No pending jobs, sleep a bit longer
#                         time.sleep(5)

#             except Exception as e:
#                 logger.error(f"❌ Error in job watcher: {e}")
#                 time.sleep(10)  # Backoff in case of error

#     watcher_thread = threading.Thread(target=watch)
#     watcher_thread.daemon = True
#     watcher_thread.start()


# @app.errorhandler(404)
# def not_found(error):
#     return jsonify({
#         "error": "Endpoint not found",
#         "message": "The requested endpoint does not exist"
#     }), 404

# @app.errorhandler(500)
# def internal_error(error):
#     return jsonify({
#         "error": "Internal server error",
#         "message": "An unexpected error occurred"
#     }), 500

# if __name__ == '__main__':
#     required_env_vars = ['GITHUB_PAT', 'GOOGLE_API_KEY']
#     missing_vars = [var for var in required_env_vars if not os.getenv(var)]

#     if missing_vars:
#         logger.warning(f"⚠️ Missing environment variables: {', '.join(missing_vars)}")
#     else:
#         logger.info("✅ All required environment variables are set")
    
#     start_job_watcher() # the main thread that continuously watches for pending jobs

#     port = int(os.getenv('PORT', 2000))
#     debug = os.getenv('FLASK_ENV') == 'development'
#     logger.info(f"🚀 Starting Flask app on port {port}")
#     app.run(host='0.0.0.0', port=port, debug=debug)

from fastapi import FastAPI, HTTPException, BackgroundTasks, Request, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
import os
import asyncio
import json
from datetime import datetime
from typing import Dict, Any, Optional
import logging
from pathlib import Path
from contextlib import asynccontextmanager
import time
from threading import Lock

# Config
from config.config import engine, Base

# DB extension
from extensions.extension import get_db

# Agent Graph
from graph import process_pr_workflow

# Models
from models.model import Job

# Logger setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# In-memory workflow trackers
workflow_results = {}
workflow_status = {}
workflow_logs = {}

# Lock for thread-safe operations
status_lock = Lock()

class JobProcessor:
    """Handles background job processing"""
    
    def __init__(self, app_instance):
        self.app = app_instance
        self.is_running = True
        self.current_job_id = None
        
    async def process_job_queue(self):
        """Continuously process pending jobs in the background"""
        while self.is_running:
            try:
                # Create a new database session for this operation
                from config.config import SessionLocal
                db = SessionLocal()
                
                try:
                    # Get the first pending job (FIFO)
                    job = db.query(Job).filter(Job.status == "pending").order_by(Job.created_at.asc()).first()
                    
                    if job:
                        workflow_id = job.workflow_id
                        pr_url = job.pr_url
                        
                        logger.info(f"👀 Detected pending job: {workflow_id}, starting processing")
                        
                        # Mark job as in-progress
                        with status_lock:
                            job.status = "in_progress"
                            self.current_job_id = workflow_id
                            db.commit()
                        
                        # Process the job
                        await self.run_workflow_async(workflow_id, pr_url, None, {
                            "post_comments": True,
                            "skip_standards_fetch": False,
                            "workflow_type": "webhook"
                        })
                        
                        # Update job status
                        with status_lock:
                            job = db.query(Job).filter(Job.workflow_id == workflow_id).first()
                            if job:
                                if workflow_id in workflow_status and workflow_status[workflow_id]["status"] == "failed":
                                    job.status = "failed"
                                else:
                                    job.status = "completed"
                                db.commit()
                            self.current_job_id = None
                        
                        # Short pause before checking for next job
                        await asyncio.sleep(3)
                    else:
                        # No pending jobs, sleep longer
                        await asyncio.sleep(5)
                        
                finally:
                    db.close()
                    
            except Exception as e:
                logger.error(f"❌ Error in job processor: {e}")
                with status_lock:
                    if self.current_job_id:
                        from config.config import SessionLocal
                        db = SessionLocal()
                        try:
                            job = db.query(Job).filter(Job.workflow_id == self.current_job_id).first()
                            if job:
                                job.status = "failed"
                                db.commit()
                        finally:
                            db.close()
                    self.current_job_id = None
                await asyncio.sleep(10)  # Backoff on error
    
    async def run_workflow_async(self, workflow_id: str, pr_url: str = None, pr_payload: Dict[str, Any] = None, config: Dict[str, Any] = None):
        """Run the workflow asynchronously"""
        try:
            logger.info(f"🚀 Starting async workflow {workflow_id}")
            
            with status_lock:
                workflow_logs[workflow_id] = []
                workflow_status[workflow_id] = {
                    "status": "running",
                    "started_at": datetime.now().isoformat(),
                    "message": "Workflow execution in progress",
                    "progress": 0
                }
                
                workflow_logs[workflow_id].append({
                    "timestamp": datetime.now().isoformat(),
                    "level": "INFO",
                    "message": f"Workflow {workflow_id} started"
                })
            
            # Run the actual workflow in a thread pool to avoid blocking
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None, 
                process_pr_workflow, 
                pr_url, 
                pr_payload, 
                config
            )
            
            with status_lock:
                workflow_results[workflow_id] = result
                workflow_status[workflow_id] = {
                    "status": "completed",
                    "started_at": workflow_status[workflow_id]["started_at"],
                    "completed_at": datetime.now().isoformat(),
                    "message": "Workflow completed successfully",
                    "progress": 100
                }
                
                workflow_logs[workflow_id].append({
                    "timestamp": datetime.now().isoformat(),
                    "level": "SUCCESS",
                    "message": f"Workflow {workflow_id} completed successfully"
                })
            
            logger.info(f"✅ Workflow {workflow_id} completed successfully")
            
        except Exception as e:
            error_msg = f"Workflow {workflow_id} failed: {str(e)}"
            logger.error(error_msg)
            
            with status_lock:
                if workflow_id in workflow_logs:
                    workflow_logs[workflow_id].append({
                        "timestamp": datetime.now().isoformat(),
                        "level": "ERROR",
                        "message": error_msg
                    })
                
                workflow_status[workflow_id] = {
                    "status": "failed",
                    "started_at": workflow_status[workflow_id].get("started_at"),
                    "completed_at": datetime.now().isoformat(),
                    "message": error_msg,
                    "error": str(e),
                    "progress": -1
                }
    
    def stop(self):
        """Stop the job processor"""
        self.is_running = False

# Global job processor instance
job_processor = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Handle application startup and shutdown"""
    global job_processor
    
    # Startup
    logger.info("🚀 Starting FastAPI application")
    
    # Check environment variables
    required_env_vars = ['GITHUB_PAT', 'GOOGLE_API_KEY']
    missing_vars = [var for var in required_env_vars if not os.getenv(var)]
    
    if missing_vars:
        logger.warning(f"⚠️ Missing environment variables: {', '.join(missing_vars)}")
    else:
        logger.info("✅ All required environment variables are set")
    
    # Create database tables
    Base.metadata.create_all(bind=engine)
    logger.info("✅ Database tables created")
    
    # Start job processor
    job_processor = JobProcessor(app)
    asyncio.create_task(job_processor.process_job_queue())
    logger.info("✅ Job processor started")
    
    yield
    
    # Shutdown
    if job_processor:
        job_processor.stop()
    logger.info("🛑 FastAPI application shutdown")

# Create FastAPI app
app = FastAPI(
    title="PR Agent API",
    description="FastAPI application for processing GitHub PR workflows",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure as needed
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ===== API ROUTES FOR FRONTEND =====

@app.get("/api/jobs")
async def get_all_jobs(db: Session = Depends(get_db)):
    """Get all PR jobs from the database"""
    try:
        jobs = db.query(Job).order_by(Job.created_at.desc()).all()
        jobs_data = []
        
        for job in jobs:
            job_data = {
                'id': job.id,
                'pr_title': job.pr_title,
                'pr_author': job.pr_author,
                'pr_url': job.pr_url,
                'pr_number': job.pr_number,
                'workflow_id': job.workflow_id,
                'status': job.status,
                'created_at': job.created_at.isoformat()
            }
            jobs_data.append(job_data)
        
        return {
            'status': 'success',
            'jobs': jobs_data,
            'count': len(jobs_data)
        }
        
    except Exception as e:
        logger.error(f"❌ Error fetching jobs: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                'error': 'Failed to fetch jobs',
                'message': str(e)
            }
        )

@app.delete("/api/jobs/{workflow_id}")
async def delete_job(workflow_id: str, db: Session = Depends(get_db)):
    """Delete a specific job by workflow_id"""
    try:
        job = db.query(Job).filter(Job.workflow_id == workflow_id).first()
        
        if not job:
            raise HTTPException(
                status_code=404,
                detail={
                    'error': 'Job not found',
                    'message': f'No job found with workflow_id: {workflow_id}'
                }
            )
        
        # Delete the job from database
        db.delete(job)
        db.commit()
        
        # Clean up any related files if they exist
        try:
            output_dir = Path("/agents/outputs")
            summary_files = list(output_dir.glob(f"summary_pr_{job.pr_number}_*.md"))
            for file in summary_files:
                if file.exists():
                    file.unlink()
                    logger.info(f"🗑️ Deleted summary file: {file}")
        except Exception as file_error:
            logger.warning(f"⚠️ Could not delete summary files: {file_error}")
        
        logger.info(f"🗑️ Job {workflow_id} deleted successfully")
        
        return {
            'status': 'success',
            'message': f'Job {workflow_id} deleted successfully'
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error deleting job {workflow_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                'error': 'Failed to delete job',
                'message': str(e)
            }
        )

@app.get("/api/jobs/{workflow_id}/summary")
async def get_job_summary(workflow_id: str, db: Session = Depends(get_db)):
    """Get the summary markdown file for a specific job"""
    try:
        job = db.query(Job).filter(Job.workflow_id == workflow_id).first()
        
        if not job:
            raise HTTPException(
                status_code=404,
                detail={
                    'error': 'Job not found',
                    'message': f'No job found with workflow_id: {workflow_id}'
                }
            )
        
        # Look for summary file in outputs directory
        output_dir = Path(__file__).parent / "agents" / "output"
        summary_files = list(output_dir.glob(f"summary_pr_{job.pr_number}_*.md"))
        
        if not summary_files:
            raise HTTPException(
                status_code=404,
                detail={
                    'error': 'Summary not found',
                    'message': f'No summary file found for PR #{job.pr_number}'
                }
            )
        
        # Get the most recent summary file (if multiple exist)
        summary_file = max(summary_files, key=os.path.getctime)
        
        # Read the markdown content
        with open(summary_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return {
            'status': 'success',
            'workflow_id': workflow_id,
            'pr_number': job.pr_number,
            'summary': content,
            'file_path': str(summary_file)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Error fetching summary for {workflow_id}: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                'error': 'Failed to fetch summary',
                'message': str(e)
            }
        )

@app.get("/api/jobs/status")
async def get_jobs_status(db: Session = Depends(get_db)):
    """Get current status of all jobs (for real-time updates)"""
    try:
        jobs = db.query(Job).all()
        status_data = {}
        
        for job in jobs:
            status_data[job.workflow_id] = {
                'id': job.id,
                'status': job.status,
                'pr_title': job.pr_title,
                'workflow_id': job.workflow_id
            }
        
        return {
            'status': 'success',
            'jobs_status': status_data
        }
        
    except Exception as e:
        logger.error(f"❌ Error fetching jobs status: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                'error': 'Failed to fetch jobs status',
                'message': str(e)
            }
        )

# ===== GITHUB WEBHOOK ROUTE =====

@app.post("/github-webhook")
async def handle_github_webhook(request: Request, db: Session = Depends(get_db)):
    """Handle GitHub webhook for PR events"""
    try:
        data = await request.json()
        action = data.get("action")
        pr_data = data.get("pull_request")

        logger.info(f"📨 Received GitHub webhook: action={action}")

        if action in ["opened", "synchronize"] and pr_data:
            pr_title = pr_data.get("title", "Untitled PR")
            pr_author = pr_data.get("user", {}).get("login", "Unknown author")
            pr_url = pr_data.get("html_url", "")
            pr_number = pr_data.get("number")

            logger.info(f"🔍 Processing PR: {pr_title} by {pr_author}")

            workflow_id = f"webhook_{pr_number}_{int(datetime.now().timestamp())}"

            # Store PR into jobs table
            new_job = Job(
                pr_title=pr_title,
                pr_author=pr_author,
                pr_url=pr_url,
                pr_number=pr_number,
                workflow_id=workflow_id,
                status="pending"
            )

            db.add(new_job)
            db.commit()
            logger.info(f"🗃️ Job {workflow_id} saved to database.")

            return JSONResponse(
                status_code=202,
                content={
                    "status": "accepted",
                    "message": f"PR saved to job queue: {pr_title}",
                    "workflow_id": workflow_id,
                    "pr_url": pr_url,
                    "pr_number": pr_number,
                    "pr_author": pr_author
                }
            )

        else:
            return {
                "status": "ignored",
                "message": f"Event action '{action}' not processed",
                "supported_actions": ["opened", "synchronize"]
            }

    except Exception as e:
        logger.error(f"❌ Webhook processing error: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "error": "Webhook processing failed",
                "message": str(e)
            }
        )

# ===== ERROR HANDLERS =====

@app.exception_handler(404)
async def not_found_handler(request: Request, exc):
    return JSONResponse(
        status_code=404,
        content={
            "error": "Endpoint not found",
            "message": "The requested endpoint does not exist"
        }
    )

@app.exception_handler(500)
async def internal_error_handler(request: Request, exc):
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "message": "An unexpected error occurred"
        }
    )

# ===== HEALTH CHECK =====

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.now().isoformat(),
        "job_processor_running": job_processor.is_running if job_processor else False
    }

if __name__ == '__main__':
    import uvicorn
    
    port = int(os.getenv('PORT', 2000))
    debug = os.getenv('FLASK_ENV') == 'development'
    
    logger.info(f"🚀 Starting FastAPI app on port {port}")
    
    uvicorn.run(
        "app:app",  # Replace "main" with your actual filename
        host="0.0.0.0",
        port=port,
        reload=debug,
        log_level="info"
    )