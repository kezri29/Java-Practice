import os
from typing import Optional, TypedDict, List, Dict, Any
from langgraph.graph import StateGraph, START, END
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()

from agents.A1_PR_details_extract import RetrievePRDetailsAgent
from agents.A2_CodingRule_fetcher import RetrieveCodingStandardsAgent
from agents.A3_Code_Review import CodeReviewAgent
from agents.A4_PR_comments import PRCommentAgent
from agents.A5_Summarizer_agent import SummarizerAgent


class PRWorkflowState(TypedDict, total=False):
    """
    Complete state schema for the PR review workflow.
    This carries all data between agents and maintains context.
    """
    # Input parameters
    pr_url: Optional[str]
    pr_payload: Optional[Dict[str, Any]]  # For webhook payloads
    repo_override: Optional[str]  # For custom repo for coding standards
    
    # Agent outputs
    pr_details: Optional[Dict[str, Any]]
    coding_standards: Optional[Dict[str, Any]]
    code_review_results: Optional[Dict[str, Any]]
    pr_comments_data: Optional[Dict[str, Any]]
    final_summary: Optional[Dict[str, Any]]
    
    # Workflow control
    current_step: Optional[str]
    processing_status: str
    workflow_started_at: Optional[str]
    workflow_completed_at: Optional[str]
    
    # Error handling
    errors: List[str]
    warnings: List[str]
    
    # Configuration
    post_comments: bool  # Whether to post comments back to GitHub
    skip_standards_fetch: bool  # Whether to skip fetching coding standards


def pr_details_extract_node(state: PRWorkflowState) -> PRWorkflowState:
    """
    Node for extracting PR details from GitHub.
    """
    print("🔄 [Step 1/5] Extracting PR details...")
    
    try:
        github_token = os.getenv("GITHUB_PAT")
        if not github_token:
            raise ValueError("GITHUB_PAT environment variable is required")
        
        agent = RetrievePRDetailsAgent(github_token)
        
        
        if state.get("pr_payload"):
            pr_details = agent.get_pr_details_from_webhook(state["pr_payload"])
        elif state.get("pr_url"):
            pr_details = agent.extract_pr_details(state["pr_url"])
        else:
            raise ValueError("Either pr_url or pr_payload must be provided")
        
        print(f"✅ PR details extracted: {pr_details.get('title', 'Unknown')} by {pr_details.get('author', 'Unknown')}")
        print(f"🔍 Extracted PR metadata: {pr_details}")

        
        return {
            **state,
            "pr_details": pr_details,
            "current_step": "pr_details_extracted",
            "processing_status": "in_progress"
        }
        
    except Exception as e:
        error_msg = f"PR details extraction failed: {str(e)}"
        print(f"❌ {error_msg}")
        return {
            **state,
            "processing_status": "failed",
            "current_step": "pr_details_failed",
            "errors": state.get("errors", []) + [error_msg]
        }


def coding_standards_fetch_node(state: PRWorkflowState) -> PRWorkflowState:
    """
    Node for fetching coding standards from repository.
    """
    print("🔄 [Step 2/5] Fetching coding standards...")
    
    if state.get("skip_standards_fetch"):
        print("⏭️ Skipping coding standards fetch as requested")
        return {
            **state,
            "coding_standards": {"source": "skipped", "content": ""},
            "current_step": "coding_standards_skipped",
            "processing_status": "in_progress"
        }
    
    try:
        github_token = os.getenv("GITHUB_PAT")
        agent = RetrieveCodingStandardsAgent(github_token)
        
        pr_details = state.get("pr_details", {})
        repo_string = state.get("repo_override") or f"{pr_details.get('repo_owner')}/{pr_details.get('repo_name')}"
        
        if not repo_string or "/" not in repo_string:
            raise ValueError("Invalid repository information")
        
        coding_standards = agent.run(repo_string)
        
        print(f"✅ Coding standards fetched: {coding_standards.get('source', 'unknown')} source")
        print(f"📘 Coding standards content preview:\n{coding_standards.get('content', '')[:500]}")
        
        return {
            **state,
            "coding_standards": coding_standards,
            "current_step": "coding_standards_fetched",
            "processing_status": "in_progress"
        }
        
    except Exception as e:
        error_msg = f"Coding standards fetch failed: {str(e)}"
        print(f"⚠️ {error_msg} - Using default standards")
        
        
        default_agent = RetrieveCodingStandardsAgent()
        default_standards = {
            "source": "default",
            "content": default_agent._get_default_java_standards(),
            "repository": "default",
            "filepath": "built-in",
            "sections": {}
        }
        
        return {
            **state,
            "coding_standards": default_standards,
            "current_step": "coding_standards_defaulted",
            "processing_status": "in_progress",
            "warnings": state.get("warnings", []) + [error_msg]
        }


def code_review_node(state: PRWorkflowState) -> PRWorkflowState:
    """
    Node for performing automated code review.
    """
    print("🔄 [Step 3/5] Performing code review...")
    
    try:
        google_api_key = os.getenv("GOOGLE_API_KEY")
        if not google_api_key:
            raise ValueError("GOOGLE_API_KEY environment variable is required")
        
        agent = CodeReviewAgent(google_api_key)
        
        pr_details = state.get("pr_details")
        coding_standards = state.get("coding_standards")
        
        if not pr_details:
            raise ValueError("PR details are required for code review")
        if not coding_standards:
            raise ValueError("Coding standards are required for code review")
        
        review_results = agent.review_code(pr_details, coding_standards)
        
        issues_found = review_results.get("total_issues_found", 0)
        files_reviewed = review_results.get("total_files_reviewed", 0)
        
        print(f"✅ Code review completed: {issues_found} issues found in {files_reviewed} files")
        
        return {
            **state,
            "code_review_results": review_results,
            "current_step": "code_review_completed",
            "processing_status": "in_progress"
        }
        
    except Exception as e:
        error_msg = f"Code review failed: {str(e)}"
        print(f"❌ {error_msg}")
        return {
            **state,
            "processing_status": "failed",
            "current_step": "code_review_failed",
            "errors": state.get("errors", []) + [error_msg]
        }


def pr_comments_node(state: PRWorkflowState) -> PRWorkflowState:
    """
    Node for handling PR comments (fetch existing and optionally post new ones).
    """
    print("🔄 [Step 4/5] Processing PR comments...")
    
    try:
        github_token = os.getenv("GITHUB_PAT")
        if not github_token:
            raise ValueError("GITHUB_PAT environment variable is required")
        
        agent = PRCommentAgent(github_token)
        
        pr_details = state.get("pr_details")
        code_review_results = state.get("code_review_results")
        
        if not pr_details:
            raise ValueError("PR details are required for comment processing")
        
       
        if state.get("post_comments", True) and code_review_results:
            comments_data = agent.run(pr_details, code_review_results)
        else:
            comments_data = agent.run(pr_details)
        
        existing_count = comments_data.get("existing_comments", {}).get("total_comments", 0)
        posted_count = comments_data.get("posted_comments", {}).get("comments_posted", 0)
        
        print(f"✅ PR comments processed: {existing_count} existing, {posted_count} posted")
        
        return {
            **state,
            "pr_comments_data": comments_data,
            "current_step": "pr_comments_processed",
            "processing_status": "in_progress"
        }
        
    except Exception as e:
        error_msg = f"PR comments processing failed: {str(e)}"
        print(f"⚠️ {error_msg} - Continuing without comment processing")
        
        
        return {
            **state,
            "pr_comments_data": {"agent_status": "error", "error": str(e)},
            "current_step": "pr_comments_failed",
            "processing_status": "in_progress",
            "warnings": state.get("warnings", []) + [error_msg]
        }


def summarizer_node(state: PRWorkflowState) -> PRWorkflowState:
    """
    Node for generating final comprehensive summary.
    """
    print("🔄 [Step 5/5] Generating comprehensive summary...")
    
    try:
        google_api_key = os.getenv("GOOGLE_API_KEY")
        if not google_api_key:
            raise ValueError("GOOGLE_API_KEY environment variable is required")
        
        agent = SummarizerAgent(google_api_key)
        
        
        workflow_data = {
            "pr_details": state.get("pr_details"),
            "coding_standards": state.get("coding_standards"),
            "code_review_results": state.get("code_review_results"),
            "pr_comments_data": state.get("pr_comments_data"),
            "workflow_metadata": {
                "started_at": state.get("workflow_started_at"),
                "errors": state.get("errors", []),
                "warnings": state.get("warnings", []),
                "steps_completed": state.get("current_step")
            }
        }
        
        summary = agent.run(workflow_data)
        
        print("✅ Comprehensive summary generated successfully")
        print(summary)
        
        return {
            **state,
            "final_summary": summary,
            "current_step": "workflow_completed",
            "processing_status": "completed",
            "workflow_completed_at": datetime.now().isoformat()
        }
        
    except Exception as e:
        error_msg = f"Summary generation failed: {str(e)}"
        print(f"❌ {error_msg}")
        
       
        fallback_summary = {
            "workflow_status": "completed_with_summary_error",
            "error": str(e),
            "pr_overview": {
                "title": state.get("pr_details", {}).get("title", "Unknown"),
                "author": state.get("pr_details", {}).get("author", "Unknown")
            },
            "basic_stats": {
                "files_changed": state.get("pr_details", {}).get("total_files_changed", 0),
                "issues_found": state.get("code_review_results", {}).get("total_issues_found", 0)
            }
        }
        
        return {
            **state,
            "final_summary": fallback_summary,
            "current_step": "workflow_completed_with_errors",
            "processing_status": "completed_with_errors",
            "workflow_completed_at": datetime.now().isoformat(),
            "errors": state.get("errors", []) + [error_msg]
        }


def determine_next_step(state: PRWorkflowState) -> str:
    """
    Router function to determine the next step in the workflow.
    """
    current_step = state.get("current_step", "")
    processing_status = state.get("processing_status", "")
    
   
    if processing_status == "failed":
        return "END"
    
    
    routing_map = {
        "": "pr_details_extract",
        "pr_details_extracted": "coding_standards_fetch",
        "coding_standards_fetched": "code_review",
        "coding_standards_defaulted": "code_review", 
        "coding_standards_skipped": "code_review",
        "code_review_completed": "pr_comments",
        "pr_comments_processed": "summarizer",
        "pr_comments_failed": "summarizer",  
        "workflow_completed": "END",
        "workflow_completed_with_errors": "END"
    }
    
    return routing_map.get(current_step, "END")


def create_pr_workflow_graph() -> StateGraph:
    """
    Create and configure the complete PR workflow graph.
    """
    print("🔧 Building PR workflow graph...")
    
    
    graph = StateGraph(PRWorkflowState)
    
    
    graph.add_node("pr_details_extract", pr_details_extract_node)
    graph.add_node("coding_standards_fetch", coding_standards_fetch_node)
    graph.add_node("code_review", code_review_node)
    graph.add_node("pr_comments", pr_comments_node)
    graph.add_node("summarizer", summarizer_node)
    
    
    graph.add_conditional_edges(
        START,
        determine_next_step,
        {
            "pr_details_extract": "pr_details_extract",
            "END": END
        }
    )
    
    graph.add_conditional_edges(
        "pr_details_extract",
        determine_next_step,
        {
            "coding_standards_fetch": "coding_standards_fetch",
            "END": END
        }
    )
    
    graph.add_conditional_edges(
        "coding_standards_fetch",
        determine_next_step,
        {
            "code_review": "code_review",
            "END": END
        }
    )
    
    graph.add_conditional_edges(
        "code_review",
        determine_next_step,
        {
            "pr_comments": "pr_comments",
            "END": END
        }
    )
    
    graph.add_conditional_edges(
        "pr_comments",
        determine_next_step,
        {
            "summarizer": "summarizer",
            "END": END
        }
    )
    
    graph.add_conditional_edges(
        "summarizer",
        determine_next_step,
        {
            "END": END
        }
    )
    
    return graph


def process_pr_workflow(pr_url: str = None, pr_payload: Dict[str, Any] = None, 
                       config: Dict[str, Any] = None) -> Dict[str, Any]:
    """
    Main function to process a PR through the complete workflow.
    
    Args:
        pr_url (str, optional): Direct PR URL
        pr_payload (Dict[str, Any], optional): GitHub webhook payload
        config (Dict[str, Any], optional): Configuration overrides
        
    Returns:
        Dict[str, Any]: Complete workflow results
    """
    print("🚀 Starting PR workflow processing...")
    
    
    default_config = {
        "post_comments": True,
        "skip_standards_fetch": False,
        "repo_override": None
    }
    
    if config:
        default_config.update(config)
    
    
    initial_state: PRWorkflowState = {
        "pr_url": pr_url,
        "pr_payload": pr_payload,
        "processing_status": "started",
        "workflow_started_at": datetime.now().isoformat(),
        "errors": [],
        "warnings": [],
        "post_comments": default_config["post_comments"],
        "skip_standards_fetch": default_config["skip_standards_fetch"],
        "repo_override": default_config["repo_override"]
    }
    
    try:
        
        graph = create_pr_workflow_graph()
        compiled_graph = graph.compile()
        
        
        print("▶️ Executing workflow...")
        final_state = compiled_graph.invoke(initial_state)
        
        
        workflow_result = {
            "status": final_state.get("processing_status", "unknown"),
            "workflow_started_at": final_state.get("workflow_started_at"),
            "workflow_completed_at": final_state.get("workflow_completed_at"),
            "final_summary": final_state.get("final_summary"),
            "pr_details": final_state.get("pr_details"),
            "review_results": final_state.get("code_review_results"),
            "errors": final_state.get("errors", []),
            "warnings": final_state.get("warnings", []),
            "steps_completed": final_state.get("current_step")
        }
        
        print(f"🎉 Workflow completed with status: {workflow_result['status']}")
        return workflow_result
        
    except Exception as e:
        error_msg = f"Workflow execution failed: {str(e)}"
        print(f"💥 {error_msg}")
        
        return {
            "status": "failed",
            "error": error_msg,
            "workflow_started_at": initial_state.get("workflow_started_at"),
            "workflow_completed_at": datetime.now().isoformat(),
            "final_summary": None,
            "errors": [error_msg]
        }