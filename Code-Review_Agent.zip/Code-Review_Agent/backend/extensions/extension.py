# extensions/extension.py

from config.config import SessionLocal

# Dependency for injecting DB session into FastAPI routes
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
