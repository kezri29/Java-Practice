# # from app import db
# from extensions.extension import db
# from datetime import datetime, timezone

# class Job(db.Model):
#     __tablename__ = 'jobs'

#     id = db.Column(db.Integer, primary_key=True)
#     pr_title = db.Column(db.String(255), nullable=False)
#     pr_author = db.Column(db.String(100), nullable=False)
#     pr_url = db.Column(db.String(500), nullable=False)
#     pr_number = db.Column(db.Integer, nullable=False)
#     workflow_id = db.Column(db.String(100), nullable=False, unique=True)
#     status = db.Column(db.String(50), nullable=False, default='pending')  # e.g. pending, running, complete, failed
#     created_at = db.Column(db.DateTime(timezone=True), default=datetime.now(timezone.utc))

#     def __repr__(self):
#         return f"<Job {self.workflow_id} | {self.status}>"

# models/model.py

from sqlalchemy import Column, Integer, String, DateTime
from datetime import datetime
from config.config import Base  # import Base from config

class Job(Base):
    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, index=True)
    workflow_id = Column(String, unique=True, index=True)
    pr_number = Column(Integer)
    pr_title = Column(String)
    pr_author = Column(String)
    pr_url = Column(String)
    status = Column(String, default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)

    def to_dict(self):
        return {
            "id": self.id,
            "workflow_id": self.workflow_id,
            "pr_number": self.pr_number,
            "pr_title": self.pr_title,
            "pr_author": self.pr_author,
            "pr_url": self.pr_url,
            "status": self.status,
            "created_at": self.created_at.isoformat()
        }
