// /** @type {import('tailwindcss').Config} */
// module.exports = {
//   content: [
//     "./src/**/*.{js,jsx,ts,tsx}",
//     "./public/index.html"
//   ],
//   theme: {
//     extend: {
//       animation: {
//         'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
//         'bounce-slow': 'bounce 2s infinite',
//         'gradient': 'gradient 3s ease infinite',
//       },
//       backdropBlur: {
//         xs: '2px',
//       },
//       colors: {
//         'glass-white': 'rgba(255, 255, 255, 0.1)',
//         'glass-black': 'rgba(0, 0, 0, 0.1)',
//       },
//       fontFamily: {
//         'mono': ['ui-monospace', 'SFMono-Regular', 'Monaco', 'Consolas', 'Liberation Mono', 'Courier New', 'monospace'],
//       },
//       boxShadow: {
//         'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
//         'glass-inset': 'inset 0 2px 4px 0 rgba(255, 255, 255, 0.1)',
//       },
//       backgroundImage: {
//         'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
//         'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
//       },
//     },
//   },
//   plugins: [],
// }

/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
    "./public/index.html",
    "./components/**/*.{js,jsx}",
  ],
  
  theme: {
    extend: {
      // Custom animations for your components
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'pulse-dot': 'pulse-dot 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'bounce-slow': 'bounce 2s infinite',
        'gradient': 'gradient 3s ease infinite',
        'shimmer': 'shimmer 2s infinite',
        'fadeIn': 'fadeIn 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) forwards',
        'slideUp': 'slideUp 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94) forwards',
        'slideIn': 'slideIn 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94) forwards',
        'spin-slow': 'spin 3s linear infinite',
      },
      
      // Enhanced backdrop blur for glassmorphism
      backdropBlur: {
        xs: '2px',
        '4xl': '72px',
        '5xl': '96px',
      },
      
      // Custom colors for your components
      colors: {
        // Glass morphism colors
        'glass': {
          'white': 'rgba(255, 255, 255, 0.1)',
          'white-light': 'rgba(255, 255, 255, 0.7)',
          'white-medium': 'rgba(255, 255, 255, 0.4)',
          'black': 'rgba(0, 0, 0, 0.1)',
          'black-medium': 'rgba(0, 0, 0, 0.4)',
        },
        
        // Status colors with variations
        'status': {
          'pending': {
            50: '#fffbeb',
            100: '#fef3c7',
            500: '#f59e0b',
            600: '#d97706',
            700: '#b45309',
          },
          'progress': {
            50: '#eff6ff',
            100: '#dbeafe',
            500: '#3b82f6',
            600: '#2563eb',
            700: '#1d4ed8',
          },
          'completed': {
            50: '#ecfdf5',
            100: '#d1fae5',
            500: '#10b981',
            600: '#059669',
            700: '#047857',
          },
          'failed': {
            50: '#fef2f2',
            100: '#fee2e2',
            500: '#ef4444',
            600: '#dc2626',
            700: '#b91c1c',
          },
        },
      },
      
      // Custom font families
      fontFamily: {
        'sans': ['Inter', 'system-ui', 'sans-serif'],
        'mono': ['JetBrains Mono', 'ui-monospace', 'SFMono-Regular', 'Monaco', 'Consolas', 'Liberation Mono', 'Courier New', 'monospace'],
        'display': ['Inter', 'system-ui', 'sans-serif'],
      },
      
      // Enhanced box shadows for depth
      boxShadow: {
        'glass': '0 8px 32px 0 rgba(31, 38, 135, 0.37)',
        'glass-light': '0 8px 32px 0 rgba(31, 38, 135, 0.15)',
        'glass-inset': 'inset 0 2px 4px 0 rgba(255, 255, 255, 0.1)',
        'card': '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)',
        'card-hover': '0 25px 50px -12px rgba(0, 0, 0, 0.15), 0 8px 16px -8px rgba(0, 0, 0, 0.1)',
        'status': '0 4px 14px 0 rgba(0, 0, 0, 0.1)',
        'glow-blue': '0 0 20px rgba(59, 130, 246, 0.5)',
        'glow-emerald': '0 0 20px rgba(16, 185, 129, 0.5)',
        'glow-amber': '0 0 20px rgba(245, 158, 11, 0.5)',
        'glow-red': '0 0 20px rgba(239, 68, 68, 0.5)',
      },
      
      // Custom background images and gradients
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        'gradient-mesh': 'radial-gradient(at 40% 20%, hsla(28,100%,74%,1) 0px, transparent 50%), radial-gradient(at 80% 0%, hsla(189,100%,56%,1) 0px, transparent 50%), radial-gradient(at 0% 50%, hsla(355,100%,93%,1) 0px, transparent 50%), radial-gradient(at 80% 50%, hsla(340,100%,76%,1) 0px, transparent 50%), radial-gradient(at 0% 100%, hsla(22,100%,77%,1) 0px, transparent 50%), radial-gradient(at 80% 100%, hsla(242,100%,70%,1) 0px, transparent 50%), radial-gradient(at 0% 0%, hsla(343,100%,76%,1) 0px, transparent 50%)',
      },
      
      // Custom border radius for modern look
      borderRadius: {
        '2xl': '1rem',
        '3xl': '1.5rem',
        '4xl': '2rem',
      },
      
      // Custom spacing for consistent layout
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '26': '6.5rem',
        '30': '7.5rem',
        '34': '8.5rem',
      },
      
      // Custom z-index values
      zIndex: {
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
      },
      
      // Typography enhancements
      fontSize: {
        '2xs': ['0.625rem', { lineHeight: '0.75rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1' }],
      },
      
      // Custom transition timing functions
      transitionTimingFunction: {
        'bounce-in': 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
        'smooth': 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
        'elastic': 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
      },
      
      // Custom transition durations
      transitionDuration: {
        '400': '400ms',
        '600': '600ms',
        '800': '800ms',
      },
      
      // Custom transform scale values
      scale: {
        '102': '1.02',
        '103': '1.03',
        '97': '0.97',
        '98': '0.98',
      },
      
      // Custom blur values
      blur: {
        '4xl': '72px',
        '5xl': '96px',
      },
      
      // Custom backdrop filters
      backdropSaturate: {
        '180': '1.8',
      },
      
      backdropBrightness: {
        '110': '1.1',
        '120': '1.2',
      },
    },
  },
  
  // Plugins for additional utilities
  plugins: [
    // Add plugin for custom utilities if needed
    function({ addUtilities, theme }) {
      const newUtilities = {
        '.text-shadow': {
          textShadow: '0 1px 3px rgba(0, 0, 0, 0.1)',
        },
        '.text-shadow-md': {
          textShadow: '0 4px 8px rgba(0, 0, 0, 0.12), 0 2px 4px rgba(0, 0, 0, 0.08)',
        },
        '.text-shadow-lg': {
          textShadow: '0 15px 35px rgba(0, 0, 0, 0.1), 0 5px 15px rgba(0, 0, 0, 0.07)',
        },
        '.animation-delay-75': {
          'animation-delay': '75ms',
        },
        '.animation-delay-100': {
          'animation-delay': '100ms',
        },
        '.animation-delay-150': {
          'animation-delay': '150ms',
        },
        '.animation-delay-200': {
          'animation-delay': '200ms',
        },
        '.animation-delay-300': {
          'animation-delay': '300ms',
        },
      }
      
      addUtilities(newUtilities)
    }
  ],
  
  // Safelist for dynamic classes used in your components
  safelist: [
    'animate-pulse',
    'animate-spin',
    'animate-bounce',
    'animate-pulse-slow',
    'animate-gradient',
    'bg-gradient-to-br',
    'from-blue-500',
    'to-indigo-600',
    'from-emerald-500',
    'to-green-600',
    'from-amber-500',
    'to-orange-600',
    'from-red-500',
    'to-rose-600',
    'glass-light',
    'glass-medium',
    'card-hover',
    'status-pending',
    'status-progress',
    'status-completed',
    'status-failed',
    {
      pattern: /bg-(red|green|blue|yellow|indigo|purple|pink)-(50|100|200|300|400|500|600|700|800|900)/,
    },
    {
      pattern: /text-(red|green|blue|yellow|indigo|purple|pink)-(50|100|200|300|400|500|600|700|800|900)/,
    },
    {
      pattern: /border-(red|green|blue|yellow|indigo|purple|pink)-(50|100|200|300|400|500|600|700|800|900)/,
    },
    {
      pattern: /from-(red|green|blue|yellow|indigo|purple|pink)-(50|100|200|300|400|500|600|700|800|900)/,
    },
    {
      pattern: /to-(red|green|blue|yellow|indigo|purple|pink)-(50|100|200|300|400|500|600|700|800|900)/,
    },
  ],
}