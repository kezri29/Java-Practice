// import React from 'react';
// import { RefreshCw, GitPullRequest, Zap, CheckCircle2, XCircle, Clock } from 'lucide-react';
// import JobCard from './JobCard';
// import toast from 'react-hot-toast';

// const JobDashboard = ({ jobs, loading, onDeleteJob, onViewSummary, onRefresh }) => {
//   const handleRefresh = () => {
//     onRefresh();
//     toast.success('Jobs refreshed!');
//   };

//   const getStatusCounts = () => {
//     const counts = {
//       pending: jobs.filter(job => job.status === 'pending').length,
//       in_progress: jobs.filter(job => job.status === 'in_progress').length,
//       completed: jobs.filter(job => job.status === 'completed').length,
//       failed: jobs.filter(job => job.status === 'failed').length,
//     };
//     return counts;
//   };

//   const statusCounts = getStatusCounts();

//   if (loading) {
//     return (
//       <div className="flex items-center justify-center min-h-96">
//         <div className="relative">
//           <div className="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
//           <div className="absolute inset-0 flex items-center justify-center">
//             <GitPullRequest className="w-6 h-6 text-blue-600" />
//           </div>
//         </div>
//       </div>
//     );
//   }

//   return (
//     <div className="space-y-8">
//       {/* Stats Section */}
//       <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
//         <div className="bg-white/70 backdrop-blur-sm border border-white/50 rounded-2xl p-6 shadow-lg">
//           <div className="flex items-center justify-between">
//             <div>
//               <p className="text-sm font-medium text-slate-600">Pending</p>
//               <p className="text-3xl font-bold text-amber-600">{statusCounts.pending}</p>
//             </div>
//             <Clock className="w-8 h-8 text-amber-500" />
//           </div>
//         </div>

//         <div className="bg-white/70 backdrop-blur-sm border border-white/50 rounded-2xl p-6 shadow-lg">
//           <div className="flex items-center justify-between">
//             <div>
//               <p className="text-sm font-medium text-slate-600">In Progress</p>
//               <p className="text-3xl font-bold text-blue-600">{statusCounts.in_progress}</p>
//             </div>
//             <Zap className="w-8 h-8 text-blue-500" />
//           </div>
//         </div>

//         <div className="bg-white/70 backdrop-blur-sm border border-white/50 rounded-2xl p-6 shadow-lg">
//           <div className="flex items-center justify-between">
//             <div>
//               <p className="text-sm font-medium text-slate-600">Completed</p>
//               <p className="text-3xl font-bold text-emerald-600">{statusCounts.completed}</p>
//             </div>
//             <CheckCircle2 className="w-8 h-8 text-emerald-500" />
//           </div>
//         </div>

//         <div className="bg-white/70 backdrop-blur-sm border border-white/50 rounded-2xl p-6 shadow-lg">
//           <div className="flex items-center justify-between">
//             <div>
//               <p className="text-sm font-medium text-slate-600">Failed</p>
//               <p className="text-3xl font-bold text-red-600">{statusCounts.failed}</p>
//             </div>
//             <XCircle className="w-8 h-8 text-red-500" />
//           </div>
//         </div>
//       </div>

//       {/* Header with Refresh */}
//       <div className="flex items-center justify-between mb-6">
//         <div className="flex items-center space-x-3">
//           <GitPullRequest className="w-7 h-7 text-slate-700" />
//           <h2 className="text-2xl font-bold text-slate-800">
//             Pull Request Jobs ({jobs.length})
//           </h2>
//         </div>
        
//         <button
//           onClick={handleRefresh}
//           className="flex items-center space-x-2 px-4 py-2 bg-white/70 hover:bg-white/90 backdrop-blur-sm border border-white/50 rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl group"
//         >
//           <RefreshCw className="w-4 h-4 text-slate-600 group-hover:rotate-180 transition-transform duration-500" />
//           <span className="text-slate-700 font-medium">Refresh</span>
//         </button>
//       </div>

//       {/* Jobs Grid */}
//       {jobs.length === 0 ? (
//         <div className="text-center py-16">
//           <div className="w-24 h-24 mx-auto mb-6 bg-slate-100 rounded-full flex items-center justify-center">
//             <GitPullRequest className="w-12 h-12 text-slate-400" />
//           </div>
//           <h3 className="text-xl font-semibold text-slate-600 mb-2">No PR jobs found</h3>
//           <p className="text-slate-500">Pull request jobs will appear here when webhooks are received</p>
//         </div>
//       ) : (
//         <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
//           {jobs.map((job) => (
//             <JobCard
//               key={job.id}
//               job={job}
//               onDelete={() => onDeleteJob(job.workflow_id)}
//               onViewSummary={() => onViewSummary(job)}
//             />
//           ))}
//         </div>
//       )}
//     </div>
//   );
// };

// export default JobDashboard;

import React, { useState, useEffect, useMemo } from 'react';
import { 
  RefreshCw, 
  GitPullRequest, 
  Zap, 
  CheckCircle2, 
  XCircle, 
  Clock,
  TrendingUp,
  Activity,
  Filter,
  Search,
  SortAsc,
  SortDesc
} from 'lucide-react';
import JobCard from './JobCard';
import toast from 'react-hot-toast';

const JobDashboard = ({ jobs, loading, onDeleteJob, onViewSummary, onRefresh, isConnected }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [sortBy, setSortBy] = useState('newest');
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Update last updated time when jobs change
  useEffect(() => {
    if (jobs.length > 0) {
      setLastUpdated(new Date());
    }
  }, [jobs]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await onRefresh();
      toast.success('Jobs refreshed successfully!', {
        icon: '🔄',
        duration: 2000,
      });
      setLastUpdated(new Date());
    } catch (error) {
      toast.error('Failed to refresh jobs');
    } finally {
      setIsRefreshing(false);
    }
  };

  const getStatusCounts = useMemo(() => {
    const counts = {
      pending: jobs.filter(job => job.status === 'pending').length,
      in_progress: jobs.filter(job => job.status === 'in_progress').length,
      completed: jobs.filter(job => job.status === 'completed').length,
      failed: jobs.filter(job => job.status === 'failed').length,
      total: jobs.length
    };
    return counts;
  }, [jobs]);

  const filteredAndSortedJobs = useMemo(() => {
    let filtered = jobs;

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(job =>
        job.pr_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.pr_author.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.pr_number.toString().includes(searchTerm)
      );
    }

    // Filter by status
    if (statusFilter !== 'all') {
      filtered = filtered.filter(job => job.status === statusFilter);
    }

    // Sort jobs
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'newest':
          return new Date(b.created_at) - new Date(a.created_at);
        case 'oldest':
          return new Date(a.created_at) - new Date(b.created_at);
        case 'pr_number':
          return b.pr_number - a.pr_number;
        case 'author':
          return a.pr_author.localeCompare(b.pr_author);
        default:
          return 0;
      }
    });

    return filtered;
  }, [jobs, searchTerm, statusFilter, sortBy]);

  const statusConfig = {
    pending: {
      color: 'from-amber-500 to-orange-500',
      bgColor: 'bg-amber-50',
      textColor: 'text-amber-700',
      icon: Clock,
      description: 'Waiting for processing'
    },
    in_progress: {
      color: 'from-blue-500 to-indigo-600',
      bgColor: 'bg-blue-50',
      textColor: 'text-blue-700',
      icon: Zap,
      description: 'AI agents analyzing'
    },
    completed: {
      color: 'from-emerald-500 to-green-600',
      bgColor: 'bg-emerald-50',
      textColor: 'text-emerald-700',
      icon: CheckCircle2,
      description: 'Review completed'
    },
    failed: {
      color: 'from-red-500 to-rose-600',
      bgColor: 'bg-red-50',
      textColor: 'text-red-700',
      icon: XCircle,
      description: 'Processing failed'
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="relative">
          <div className="w-20 h-20 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <GitPullRequest className="w-8 h-8 text-blue-600 animate-pulse" />
          </div>
        </div>
        <div className="ml-4">
          <h3 className="text-lg font-semibold text-slate-700">Loading Dashboard</h3>
          <p className="text-slate-500">Fetching latest PR jobs...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Enhanced Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {Object.entries(statusConfig).map(([status, config]) => {
          const count = getStatusCounts[status];
          const StatusIcon = config.icon;
          const percentage = getStatusCounts.total > 0 ? (count / getStatusCounts.total * 100) : 0;
          
          return (
            <div 
              key={status}
              className={`group relative overflow-hidden ${config.bgColor} border border-white/60 rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-500 cursor-pointer hover:scale-105`}
              onClick={() => setStatusFilter(statusFilter === status ? 'all' : status)}
            >
              {/* Background gradient */}
              <div className={`absolute inset-0 bg-gradient-to-br ${config.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
              
              <div className="relative flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-slate-600 mb-1 capitalize">
                    {status.replace('_', ' ')}
                  </p>
                  <p className={`text-3xl font-bold ${config.textColor} mb-1`}>
                    {count}
                  </p>
                  <p className="text-xs text-slate-500">
                    {config.description}
                  </p>
                  {percentage > 0 && (
                    <div className="mt-2">
                      <div className="w-full bg-white/50 rounded-full h-1">
                        <div 
                          className={`bg-gradient-to-r ${config.color} h-1 rounded-full transition-all duration-1000`}
                          style={{ width: `${percentage}%` }}
                        />
                      </div>
                      <p className="text-xs text-slate-500 mt-1">{percentage.toFixed(1)}% of total</p>
                    </div>
                  )}
                </div>
                <div className={`w-12 h-12 bg-gradient-to-br ${config.color} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:rotate-12 transition-all duration-300`}>
                  <StatusIcon className="w-6 h-6 text-white" />
                </div>
              </div>
              
              {/* Selection indicator */}
              {statusFilter === status && (
                <div className="absolute top-2 right-2">
                  <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Enhanced Header with Controls */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/60 rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          {/* Title and Status */}
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-slate-600 to-slate-800 rounded-xl flex items-center justify-center">
                <GitPullRequest className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-slate-800">
                  PR Review Dashboard
                </h2>
                <div className="flex items-center space-x-4 text-sm text-slate-600">
                  <span>{filteredAndSortedJobs.length} of {jobs.length} jobs</span>
                  <span>•</span>
                  <div className="flex items-center space-x-2">
                    <div className={`w-2 h-2 rounded-full ${isConnected ? 'bg-emerald-500 animate-pulse' : 'bg-red-500'}`} />
                    <span>{isConnected ? 'Connected' : 'Disconnected'}</span>
                  </div>
                  <span>•</span>
                  <span>Updated {lastUpdated.toLocaleTimeString()}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Controls */}
          <div className="flex items-center space-x-3">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search PRs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 pr-4 py-2 bg-white/80 border border-white/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent backdrop-blur-sm min-w-[200px]"
              />
            </div>

            {/* Sort */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-4 py-2 bg-white/80 border border-white/60 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 backdrop-blur-sm"
            >
              <option value="newest">Newest First</option>
              <option value="oldest">Oldest First</option>
              <option value="pr_number">PR Number</option>
              <option value="author">Author</option>
            </select>

            {/* Filter indicator */}
            {(statusFilter !== 'all' || searchTerm) && (
              <button
                onClick={() => {
                  setStatusFilter('all');
                  setSearchTerm('');
                }}
                className="flex items-center space-x-1 px-3 py-2 bg-blue-100 text-blue-700 border border-blue-200 rounded-xl text-sm font-medium hover:bg-blue-200 transition-colors"
              >
                <Filter className="w-4 h-4" />
                <span>Clear</span>
              </button>
            )}

            {/* Refresh */}
            <button
              onClick={handleRefresh}
              disabled={isRefreshing}
              className="flex items-center space-x-2 px-4 py-2 bg-gradient-to-r from-blue-500 to-indigo-600 text-white rounded-xl shadow-lg transition-all duration-200 hover:shadow-xl hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed group"
            >
              <RefreshCw className={`w-4 h-4 transition-transform duration-500 ${isRefreshing ? 'animate-spin' : 'group-hover:rotate-180'}`} />
              <span className="font-medium">
                {isRefreshing ? 'Refreshing...' : 'Refresh'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Active Status Banner for In-Progress Jobs */}
      {getStatusCounts.in_progress > 0 && (
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
              <Activity className="w-4 h-4 text-white animate-pulse" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-blue-900">
                {getStatusCounts.in_progress} AI Agent{getStatusCounts.in_progress !== 1 ? 's' : ''} Active
              </h3>
              <p className="text-sm text-blue-700">
                Code reviews are being processed in real-time
              </p>
            </div>
            <div className="flex space-x-1">
              {[...Array(3)].map((_, i) => (
                <div 
                  key={i}
                  className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"
                  style={{ animationDelay: `${i * 0.2}s` }}
                />
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Jobs Grid */}
      {filteredAndSortedJobs.length === 0 ? (
        <div className="text-center py-16">
          <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-slate-100 to-slate-200 rounded-full flex items-center justify-center">
            <GitPullRequest className="w-12 h-12 text-slate-400" />
          </div>
          <h3 className="text-xl font-semibold text-slate-600 mb-2">
            {searchTerm || statusFilter !== 'all' ? 'No matching jobs found' : 'No PR jobs found'}
          </h3>
          <p className="text-slate-500 max-w-md mx-auto">
            {searchTerm || statusFilter !== 'all' 
              ? 'Try adjusting your search or filter criteria'
              : 'Pull request jobs will appear here when webhooks are received from GitHub'
            }
          </p>
          {(searchTerm || statusFilter !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setStatusFilter('all');
              }}
              className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
            >
              Clear Filters
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredAndSortedJobs.map((job, index) => (
            <div
              key={job.id}
              className="animate-in slide-in-from-bottom duration-500"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <JobCard
                job={job}
                onDelete={() => onDeleteJob(job.workflow_id)}
                onViewSummary={() => onViewSummary(job)}
                showProgress={true}
              />
            </div>
          ))}
        </div>
      )}

      {/* Performance Metrics Footer */}
      {jobs.length > 0 && (
        <div className="bg-white/50 backdrop-blur-sm border border-white/40 rounded-2xl p-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <p className="text-lg font-bold text-slate-700">{getStatusCounts.total}</p>
              <p className="text-xs text-slate-500">Total Jobs</p>
            </div>
            <div>
              <p className="text-lg font-bold text-emerald-600">{getStatusCounts.completed}</p>
              <p className="text-xs text-slate-500">Completed</p>
            </div>
            <div>
              <p className="text-lg font-bold text-blue-600">{getStatusCounts.in_progress}</p>
              <p className="text-xs text-slate-500">Processing</p>
            </div>
            <div>
              <p className="text-lg font-bold text-amber-600">
                {getStatusCounts.total > 0 ? Math.round((getStatusCounts.completed / getStatusCounts.total) * 100) : 0}%
              </p>
              <p className="text-xs text-slate-500">Success Rate</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobDashboard;