// import React, { useState, useEffect } from 'react';
// import { X, FileText, Download, ExternalLink, Loader2 } from 'lucide-react';
// import ReactMarkdown from 'react-markdown';
// import api from '../services/api';
// import { useCallback } from 'react';



// const SummaryModal = ({ job, isOpen, onClose }) => {
//   const [summary, setSummary] = useState('');
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);

//     const fetchSummary = useCallback(async () => {
//     try {
//         setLoading(true);
//         setError(null);
//         const data = await api.getJobSummary(job.workflow_id);
//         setSummary(data.summary || 'No summary available');
//     } catch (err) {
//         setError(err.message || 'Failed to load summary');
//         setSummary('');
//     } finally {
//         setLoading(false);
//     }
//     }, [job]);


//     useEffect(() => {
//     if (isOpen && job) {
//         fetchSummary();
//     }
//     }, [isOpen, job, fetchSummary]);


//   const downloadSummary = () => {
//     const element = document.createElement('a');
//     const file = new Blob([summary], { type: 'text/markdown' });
//     element.href = URL.createObjectURL(file);
//     element.download = `summary_pr_${job.pr_number}_${new Date().toISOString().slice(0, 10)}.md`;
//     document.body.appendChild(element);
//     element.click();
//     document.body.removeChild(element);
//   };

//   if (!isOpen) return null;

//   return (
//     <div className="fixed inset-0 z-50 flex items-center justify-center">
//       {/* Backdrop */}
//       <div 
//         className="absolute inset-0 bg-black/50 backdrop-blur-sm"
//         onClick={onClose}
//       />
      
//       {/* Modal */}
//       <div className="relative w-full max-w-4xl max-h-[90vh] mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden">
//         {/* Header */}
//         <div className="flex items-center justify-between p-6 border-b border-slate-200 bg-gradient-to-r from-slate-50 to-blue-50">
//           <div className="flex items-center space-x-3">
//             <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
//               <FileText className="w-5 h-5 text-white" />
//             </div>
//             <div>
//               <h2 className="text-xl font-bold text-slate-800">
//                 Code Review Summary
//               </h2>
//               <p className="text-sm text-slate-600">
//                 {job.pr_title} • PR #{job.pr_number}
//               </p>
//             </div>
//           </div>
          
//           <div className="flex items-center space-x-2">
//             {!loading && !error && (
//               <button
//                 onClick={downloadSummary}
//                 className="flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-700 hover:bg-blue-200 border border-blue-200 rounded-xl text-sm font-medium transition-all duration-200 hover:shadow-md"
//               >
//                 <Download className="w-4 h-4" />
//                 <span>Download</span>
//               </button>
//             )}
            
//             <a
//               href={job.pr_url}
//               target="_blank"
//               rel="noopener noreferrer"
//               className="flex items-center space-x-2 px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 rounded-xl text-sm font-medium transition-all duration-200 hover:shadow-md"
//             >
//               <ExternalLink className="w-4 h-4" />
//               <span>GitHub</span>
//             </a>
            
//             <button
//               onClick={onClose}
//               className="p-2 hover:bg-slate-100 rounded-xl transition-colors duration-200"
//             >
//               <X className="w-5 h-5 text-slate-600" />
//             </button>
//           </div>
//         </div>

//         {/* Content */}
//         <div className="p-6 max-h-[calc(90vh-120px)] overflow-y-auto">
//           {loading && (
//             <div className="flex items-center justify-center py-12">
//               <div className="flex items-center space-x-3">
//                 <Loader2 className="w-6 h-6 text-blue-600 animate-spin" />
//                 <span className="text-slate-600">Loading summary...</span>
//               </div>
//             </div>
//           )}

//           {error && (
//             <div className="text-center py-12">
//               <div className="w-16 h-16 mx-auto mb-4 bg-red-100 rounded-full flex items-center justify-center">
//                 <X className="w-8 h-8 text-red-600" />
//               </div>
//               <h3 className="text-lg font-semibold text-slate-800 mb-2">Error Loading Summary</h3>
//               <p className="text-slate-600 mb-4">{error}</p>
//               <button
//                 onClick={fetchSummary}
//                 className="px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors duration-200"
//               >
//                 Try Again
//               </button>
//             </div>
//           )}

//           {!loading && !error && summary && (
//             <div className="prose prose-slate max-w-none">
//               <ReactMarkdown
//                 components={{
//                   h1: ({ children }) => (
//                     <h1 className="text-2xl font-bold text-slate-800 mb-4 pb-2 border-b border-slate-200">
//                       {children}
//                     </h1>
//                   ),
//                   h2: ({ children }) => (
//                     <h2 className="text-xl font-semibold text-slate-800 mb-3 mt-6">
//                       {children}
//                     </h2>
//                   ),
//                   h3: ({ children }) => (
//                     <h3 className="text-lg font-semibold text-slate-700 mb-2 mt-4">
//                       {children}
//                     </h3>
//                   ),
//                   p: ({ children }) => (
//                     <p className="text-slate-600 mb-3 leading-relaxed">
//                       {children}
//                     </p>
//                   ),
//                   ul: ({ children }) => (
//                     <ul className="list-disc pl-6 mb-4 space-y-1">
//                       {children}
//                     </ul>
//                   ),
//                   ol: ({ children }) => (
//                     <ol className="list-decimal pl-6 mb-4 space-y-1">
//                       {children}
//                     </ol>
//                   ),
//                   li: ({ children }) => (
//                     <li className="text-slate-600">
//                       {children}
//                     </li>
//                   ),
//                   code: ({ inline, children }) => (
//                     inline ? (
//                       <code className="bg-slate-100 text-slate-800 px-2 py-1 rounded text-sm font-mono">
//                         {children}
//                       </code>
//                     ) : (
//                       <code className="block bg-slate-900 text-slate-100 p-4 rounded-xl overflow-x-auto text-sm font-mono">
//                         {children}
//                       </code>
//                     )
//                   ),
//                   blockquote: ({ children }) => (
//                     <blockquote className="border-l-4 border-blue-500 pl-4 my-4 italic text-slate-600 bg-blue-50 py-2 rounded-r-lg">
//                       {children}
//                     </blockquote>
//                   ),
//                 }}
//               >
//                 {summary}
//               </ReactMarkdown>
//             </div>
//           )}

//           {!loading && !error && !summary && (
//             <div className="text-center py-12">
//               <div className="w-16 h-16 mx-auto mb-4 bg-slate-100 rounded-full flex items-center justify-center">
//                 <FileText className="w-8 h-8 text-slate-400" />
//               </div>
//               <h3 className="text-lg font-semibold text-slate-600 mb-2">No Summary Available</h3>
//               <p className="text-slate-500">The summary file could not be found or is empty.</p>
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SummaryModal;

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { X, FileText, Download, ExternalLink, Loader2, RefreshCw, AlertCircle, CheckCircle, Copy, Eye } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import api from '../services/api';

const SummaryModal = ({ job, isOpen, onClose }) => {
  const [summary, setSummary] = useState('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [copySuccess, setCopySuccess] = useState(false);
  const [retryCount, setRetryCount] = useState(0);
  const modalRef = useRef(null);
  const timeoutRef = useRef(null);

  const fetchSummary = useCallback(async () => {
    if (!job?.workflow_id) return;

    try {
      setLoading(true);
      setError(null);
      
      const data = await api.getJobSummary(job.workflow_id);
      
      if (data?.summary) {
        setSummary(data.summary);
        setRetryCount(0);
      } else {
        setSummary('');
        setError('No summary content available');
      }
    } catch (err) {
      console.error('Failed to fetch summary:', err);
      setError(err.message || 'Failed to load summary');
      setSummary('');
      setRetryCount(prev => prev + 1);
    } finally {
      setLoading(false);
    }
  }, [job?.workflow_id]);

  useEffect(() => {
    if (isOpen && job) {
      fetchSummary();
    } else {
      // Reset state when modal closes
      setSummary('');
      setError(null);
      setRetryCount(0);
      setCopySuccess(false);
    }
  }, [isOpen, job, fetchSummary]);

  useEffect(() => {
    const handleEscapeKey = (event) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscapeKey);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscapeKey);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  const downloadSummary = useCallback(() => {
    if (!summary) return;

    try {
      const element = document.createElement('a');
      const file = new Blob([summary], { type: 'text/markdown' });
      element.href = URL.createObjectURL(file);
      element.download = `code-review-summary-pr-${job.pr_number}-${new Date().toISOString().slice(0, 10)}.md`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      URL.revokeObjectURL(element.href);
    } catch (err) {
      console.error('Failed to download summary:', err);
    }
  }, [summary, job?.pr_number]);

  const copySummary = useCallback(async () => {
    if (!summary) return;

    try {
      await navigator.clipboard.writeText(summary);
      setCopySuccess(true);
      
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      
      timeoutRef.current = setTimeout(() => {
        setCopySuccess(false);
      }, 2000);
    } catch (err) {
      console.error('Failed to copy summary:', err);
    }
  }, [summary]);

  const handleRetry = useCallback(() => {
    fetchSummary();
  }, [fetchSummary]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center animate-fadeIn">
      {/* Enhanced Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-md transition-all duration-300"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div 
        ref={modalRef}
        className="relative w-full max-w-5xl max-h-[95vh] mx-4 bg-white rounded-3xl shadow-2xl overflow-hidden animate-slideUp border border-slate-200/50"
      >
        {/* Enhanced Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-200/50 bg-gradient-to-r from-slate-50/80 via-blue-50/60 to-indigo-50/80 backdrop-blur-sm">
          <div className="flex items-center space-x-4">
            <div className="relative">
              <div className="w-12 h-12 bg-gradient-to-br from-blue-500 via-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <div className="absolute -top-1 -right-1 w-4 h-4 bg-green-500 rounded-full border-2 border-white animate-pulse" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-800 tracking-tight">
                Code Review Summary
              </h2>
              <p className="text-sm text-slate-600 font-medium">
                {job?.pr_title || 'Unknown PR'} • PR #{job?.pr_number || 'N/A'}
              </p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {!loading && !error && summary && (
              <>
                <button
                  onClick={copySummary}
                  className="flex items-center space-x-2 px-4 py-2 bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border border-emerald-200 rounded-xl text-sm font-medium transition-all duration-200 hover:shadow-md hover:scale-105 active:scale-95"
                >
                  {copySuccess ? (
                    <>
                      <CheckCircle className="w-4 h-4" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
                
                <button
                  onClick={downloadSummary}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-100 text-blue-700 hover:bg-blue-200 border border-blue-200 rounded-xl text-sm font-medium transition-all duration-200 hover:shadow-md hover:scale-105 active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Download</span>
                </button>
              </>
            )}
            
            {job?.pr_url && (
              <a
                href={job.pr_url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center space-x-2 px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200 rounded-xl text-sm font-medium transition-all duration-200 hover:shadow-md hover:scale-105 active:scale-95"
              >
                <ExternalLink className="w-4 h-4" />
                <span>GitHub</span>
              </a>
            )}
            
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-100 rounded-xl transition-all duration-200 hover:scale-105 active:scale-95"
            >
              <X className="w-5 h-5 text-slate-600" />
            </button>
          </div>
        </div>

        {/* Enhanced Content */}
        <div className="max-h-[calc(95vh-140px)] overflow-y-auto custom-scrollbar">
          {loading && (
            <div className="flex flex-col items-center justify-center py-16 space-y-4">
              <div className="relative">
                <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
                <div className="absolute inset-0 w-8 h-8 border-2 border-blue-200 rounded-full animate-ping" />
              </div>
              <div className="text-center">
                <span className="text-slate-700 font-medium">Loading summary...</span>
                <p className="text-sm text-slate-500 mt-1">This may take a few moments</p>
              </div>
            </div>
          )}

          {error && (
            <div className="text-center py-16 px-6">
              <div className="w-20 h-20 mx-auto mb-6 bg-red-100 rounded-full flex items-center justify-center animate-bounce">
                <AlertCircle className="w-10 h-10 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-slate-800 mb-3">Unable to Load Summary</h3>
              <p className="text-slate-600 mb-6 max-w-md mx-auto leading-relaxed">{error}</p>
              {retryCount < 3 && (
                <button
                  onClick={handleRetry}
                  className="inline-flex items-center space-x-2 px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-all duration-200 hover:shadow-lg hover:scale-105 active:scale-95"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Try Again</span>
                </button>
              )}
              {retryCount >= 3 && (
                <p className="text-sm text-slate-500 mt-4">
                  Please try again later or contact support if the issue persists.
                </p>
              )}
            </div>
          )}

          {!loading && !error && summary && (
            <div className="p-8">
              <div className="prose prose-slate max-w-none prose-lg">
                <ReactMarkdown
                  components={{
                    h1: ({ children }) => (
                      <h1 className="text-3xl font-bold text-slate-800 mb-6 pb-3 border-b-2 border-gradient-to-r from-blue-500 to-indigo-500 bg-gradient-to-r from-blue-500 to-indigo-500 bg-clip-text text-transparent">
                        {children}
                      </h1>
                    ),
                    h2: ({ children }) => (
                      <h2 className="text-2xl font-bold text-slate-800 mb-4 mt-8 flex items-center">
                        <span className="w-2 h-8 bg-gradient-to-b from-blue-500 to-indigo-500 rounded-full mr-3" />
                        {children}
                      </h2>
                    ),
                    h3: ({ children }) => (
                      <h3 className="text-xl font-semibold text-slate-700 mb-3 mt-6 flex items-center">
                        <span className="w-1.5 h-6 bg-gradient-to-b from-indigo-400 to-purple-500 rounded-full mr-3" />
                        {children}
                      </h3>
                    ),
                    p: ({ children }) => (
                      <p className="text-slate-600 mb-4 leading-relaxed text-base">
                        {children}
                      </p>
                    ),
                    ul: ({ children }) => (
                      <ul className="list-none pl-0 mb-6 space-y-2">
                        {children}
                      </ul>
                    ),
                    ol: ({ children }) => (
                      <ol className="list-decimal pl-6 mb-6 space-y-2">
                        {children}
                      </ol>
                    ),
                    li: ({ children }) => (
                      <li className="text-slate-600 flex items-start">
                        <span className="w-2 h-2 bg-blue-500 rounded-full mr-3 mt-2 flex-shrink-0" />
                        <span>{children}</span>
                      </li>
                    ),
                    code: ({ inline, children }) => (
                      inline ? (
                        <code className="bg-slate-100 text-slate-800 px-2 py-1 rounded-md text-sm font-mono border border-slate-200">
                          {children}
                        </code>
                      ) : (
                        <div className="relative my-6">
                          <pre className="bg-slate-900 text-slate-100 p-6 rounded-2xl overflow-x-auto text-sm font-mono border border-slate-700 shadow-lg">
                            <code>{children}</code>
                          </pre>
                          <div className="absolute top-4 right-4 flex space-x-2">
                            <div className="w-3 h-3 bg-red-500 rounded-full" />
                            <div className="w-3 h-3 bg-yellow-500 rounded-full" />
                            <div className="w-3 h-3 bg-green-500 rounded-full" />
                          </div>
                        </div>
                      )
                    ),
                    blockquote: ({ children }) => (
                      <blockquote className="border-l-4 border-blue-500 pl-6 my-6 bg-gradient-to-r from-blue-50 to-indigo-50 py-4 rounded-r-xl">
                        <div className="text-slate-700 italic">{children}</div>
                      </blockquote>
                    ),
                    table: ({ children }) => (
                      <div className="overflow-x-auto my-6">
                        <table className="min-w-full border-collapse border border-slate-300 rounded-lg overflow-hidden shadow-sm">
                          {children}
                        </table>
                      </div>
                    ),
                    th: ({ children }) => (
                      <th className="border border-slate-300 bg-slate-100 px-4 py-2 text-left font-semibold text-slate-800">
                        {children}
                      </th>
                    ),
                    td: ({ children }) => (
                      <td className="border border-slate-300 px-4 py-2 text-slate-600">
                        {children}
                      </td>
                    ),
                  }}
                >
                  {summary}
                </ReactMarkdown>
              </div>
            </div>
          )}

          {!loading && !error && !summary && (
            <div className="text-center py-16 px-6">
              <div className="w-20 h-20 mx-auto mb-6 bg-slate-100 rounded-full flex items-center justify-center">
                <Eye className="w-10 h-10 text-slate-400" />
              </div>
              <h3 className="text-xl font-semibold text-slate-600 mb-3">No Summary Available</h3>
              <p className="text-slate-500 max-w-md mx-auto leading-relaxed">
                The summary for this pull request hasn't been generated yet or is currently unavailable.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SummaryModal;