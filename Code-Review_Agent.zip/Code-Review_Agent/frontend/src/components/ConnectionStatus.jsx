import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, AlertCircle, CheckCircle2, Clock } from 'lucide-react';

const ConnectionStatus = ({ isOnline, apiHealthy, pollingInterval }) => {
  const [show, setShow] = useState(false);
  const [lastStatusChange, setLastStatusChange] = useState(null);

  useEffect(() => {
    // Show status temporarily when connection changes
    if (lastStatusChange !== null) {
      setShow(true);
      const timer = setTimeout(() => setShow(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [isOnline, apiHealthy, lastStatusChange]);

  useEffect(() => {
    setLastStatusChange(Date.now());
  }, [isOnline, apiHealthy]);

  const getStatusConfig = () => {
    if (!isOnline) {
      return {
        icon: WifiOff,
        color: 'bg-red-500',
        textColor: 'text-red-700',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-200',
        message: 'No internet connection'
      };
    }
    
    if (!apiHealthy) {
      return {
        icon: AlertCircle,
        color: 'bg-amber-500',
        textColor: 'text-amber-700',
        bgColor: 'bg-amber-50',
        borderColor: 'border-amber-200',
        message: 'API connection issues'
      };
    }
    
    return {
      icon: CheckCircle2,
      color: 'bg-emerald-500',
      textColor: 'text-emerald-700',
      bgColor: 'bg-emerald-50',
      borderColor: 'border-emerald-200',
      message: 'Connected'
    };
  };

  const config = getStatusConfig();
  const Icon = config.icon;
  const isConnected = isOnline && apiHealthy;

  return (
    <>
      {/* Persistent status indicator */}
      <div className="fixed top-4 left-4 z-40">
        <div className={`flex items-center space-x-2 px-3 py-2 rounded-xl backdrop-blur-sm border transition-all duration-300 ${
          isConnected 
            ? 'bg-white/70 border-white/50 text-slate-600' 
            : `${config.bgColor} ${config.borderColor} ${config.textColor}`
        }`}>
          <div className={`w-2 h-2 rounded-full ${config.color} ${!isConnected ? 'animate-pulse' : ''}`} />
          <Icon className="w-4 h-4" />
          {pollingInterval > 3000 && isConnected && (
            <>
              <Clock className="w-3 h-3 text-slate-400" />
              <span className="text-xs text-slate-500">{Math.round(pollingInterval/1000)}s</span>
            </>
          )}
        </div>
      </div>

      {/* Temporary status notification */}
      {show && (
        <div className={`fixed top-20 left-4 z-50 transform transition-all duration-500 ${
          show ? 'translate-x-0 opacity-100' : '-translate-x-full opacity-0'
        }`}>
          <div className={`flex items-center space-x-3 px-4 py-3 rounded-xl backdrop-blur-sm border shadow-lg ${
            config.bgColor
          } ${config.borderColor}`}>
            <Icon className={`w-5 h-5 ${config.textColor}`} />
            <div>
              <p className={`font-medium ${config.textColor}`}>
                {config.message}
              </p>
              {!isConnected && (
                <p className="text-xs text-slate-500 mt-1">
                  Attempting to reconnect...
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ConnectionStatus;