// import React from 'react';
// import { 
//   ExternalLink, 
//   User, 
//   Hash, 
//   Clock, 
//   Eye, 
//   Trash2, 
//   CheckCircle2, 
//   XCircle, 
//   Zap,
//   GitPullRequest
// } from 'lucide-react';
// import toast from 'react-hot-toast';

// const JobCard = ({ job, onDelete, onViewSummary }) => {
//   const getStatusColor = (status) => {
//     switch (status) {
//       case 'pending':
//         return 'bg-amber-50 text-amber-700 border-amber-200';
//       case 'in_progress':
//         return 'bg-blue-50 text-blue-700 border-blue-200';
//       case 'completed':
//         return 'bg-emerald-50 text-emerald-700 border-emerald-200';
//       case 'failed':
//         return 'bg-red-50 text-red-700 border-red-200';
//       default:
//         return 'bg-slate-50 text-slate-700 border-slate-200';
//     }
//   };

//   const getStatusIcon = (status) => {
//     switch (status) {
//       case 'pending':
//         return <Clock className="w-4 h-4" />;
//       case 'in_progress':
//         return <Zap className="w-4 h-4" />;
//       case 'completed':
//         return <CheckCircle2 className="w-4 h-4" />;
//       case 'failed':
//         return <XCircle className="w-4 h-4" />;
//       default:
//         return <Clock className="w-4 h-4" />;
//     }
//   };

//   const formatDate = (dateString) => {
//     return new Date(dateString).toLocaleString('en-US', {
//       month: 'short',
//       day: 'numeric',
//       hour: '2-digit',
//       minute: '2-digit',
//     });
//   };

//   const handleDelete = () => {
//     if (window.confirm('Are you sure you want to delete this job?')) {
//       onDelete();
//       toast.success('Job deleted successfully!');
//     }
//   };

//   const handleViewSummary = () => {
//     if (job.status !== 'completed') {
//       toast.error('Summary is only available for completed jobs');
//       return;
//     }
//     onViewSummary();
//   };

//   return (
//     <div className="bg-white/80 backdrop-blur-sm border border-white/60 rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 group hover:bg-white/90">
//       {/* Header */}
//       <div className="flex items-start justify-between mb-4">
//         <div className="flex items-center space-x-3">
//           <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
//             <GitPullRequest className="w-5 h-5 text-white" />
//           </div>
//           <div>
//             <h3 className="font-semibold text-slate-800 text-lg leading-tight group-hover:text-blue-700 transition-colors">
//               {job.pr_title}
//             </h3>
//             <div className="flex items-center space-x-2 mt-1">
//               <span className={`inline-flex items-center space-x-1 px-3 py-1 rounded-full text-xs font-medium border ${getStatusColor(job.status)}`}>
//                 {getStatusIcon(job.status)}
//                 <span className="capitalize">{job.status.replace('_', ' ')}</span>
//               </span>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Progress Bar for In Progress */}
//       {job.status === 'in_progress' && (
//         <div className="mb-4">
//           <div className="flex items-center justify-between text-xs text-slate-600 mb-2">
//             <span>Processing...</span>
//             <span>Agent Running</span>
//           </div>
//           <div className="w-full bg-slate-200 rounded-full h-2">
//             <div className="bg-gradient-to-r from-blue-500 to-indigo-600 h-2 rounded-full animate-pulse" style={{width: '60%'}}></div>
//           </div>
//         </div>
//       )}

//       {/* Job Details */}
//       <div className="space-y-3 mb-6">
//         <div className="flex items-center space-x-2 text-slate-600">
//           <User className="w-4 h-4" />
//           <span className="text-sm font-medium">{job.pr_author}</span>
//         </div>
        
//         <div className="flex items-center space-x-2 text-slate-600">
//           <Hash className="w-4 h-4" />
//           <span className="text-sm">PR #{job.pr_number}</span>
//         </div>
        
//         <div className="flex items-center space-x-2 text-slate-600">
//           <Clock className="w-4 h-4" />
//           <span className="text-sm">{formatDate(job.created_at)}</span>
//         </div>

//         <div className="flex items-center space-x-2">
//           <ExternalLink className="w-4 h-4 text-slate-500" />
//           <a 
//             href={job.pr_url} 
//             target="_blank" 
//             rel="noopener noreferrer"
//             className="text-sm text-blue-600 hover:text-blue-800 hover:underline transition-colors"
//           >
//             View on GitHub
//           </a>
//         </div>
//       </div>

//       {/* Action Buttons */}
//       <div className="flex items-center space-x-3">
//         <button
//           onClick={handleViewSummary}
//           disabled={job.status !== 'completed'}
//           className={`flex items-center space-x-2 px-4 py-2 rounded-xl text-sm font-medium transition-all duration-200 ${
//             job.status === 'completed' 
//               ? 'bg-emerald-100 text-emerald-700 hover:bg-emerald-200 border border-emerald-200 hover:shadow-md' 
//               : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
//           }`}
//         >
//           <Eye className="w-4 h-4" />
//           <span>Summary</span>
//         </button>

//         <button
//           onClick={handleDelete}
//           className="flex items-center space-x-2 px-4 py-2 bg-red-50 text-red-600 hover:bg-red-100 border border-red-200 rounded-xl text-sm font-medium transition-all duration-200 hover:shadow-md"
//         >
//           <Trash2 className="w-4 h-4" />
//           <span>Delete</span>
//         </button>
//       </div>

//       {/* Workflow ID (Hidden by default, shown on hover) */}
//       <div className="mt-4 pt-4 border-t border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
//         <p className="text-xs text-slate-500 font-mono">
//           {job.workflow_id}
//         </p>
//       </div>
//     </div>
//   );
// };

// export default JobCard;

import React, { useState, useEffect, useMemo } from 'react';
import { 
  ExternalLink, 
  User, 
  Hash, 
  Clock, 
  Eye, 
  Trash2, 
  CheckCircle2, 
  XCircle, 
  Zap,
  GitPullRequest,
  Calendar,
  Timer,
  AlertTriangle,
  Copy
} from 'lucide-react';
import toast from 'react-hot-toast';

const JobCard = ({ job, onDelete, onViewSummary, showProgress = false }) => {
  const [isDeleting, setIsDeleting] = useState(false);
  const [progress, setProgress] = useState(0);
  const [timeElapsed, setTimeElapsed] = useState(0);

  // Calculate time elapsed for in-progress jobs
  useEffect(() => {
    if (job.status === 'in_progress') {
      const startTime = new Date(job.updated_at || job.created_at);
      
      const updateElapsed = () => {
        const elapsed = Math.floor((Date.now() - startTime.getTime()) / 1000);
        setTimeElapsed(elapsed);
        
        // Simulate progress based on time (more realistic than fixed 60%)
        const progressPercent = Math.min(85, (elapsed / 300) * 100); // 85% max in 5 minutes
        setProgress(progressPercent);
      };

      updateElapsed();
      const interval = setInterval(updateElapsed, 1000);
      
      return () => clearInterval(interval);
    }
  }, [job.status, job.updated_at, job.created_at]);

  const statusConfig = useMemo(() => {
    const configs = {
      pending: {
        color: 'bg-amber-50 text-amber-700 border-amber-200',
        icon: Clock,
        bgGradient: 'from-amber-400/20 to-orange-400/20',
        iconBg: 'from-amber-500 to-orange-500'
      },
      in_progress: {
        color: 'bg-blue-50 text-blue-700 border-blue-200',
        icon: Zap,
        bgGradient: 'from-blue-400/20 to-indigo-400/20',
        iconBg: 'from-blue-500 to-indigo-500'
      },
      completed: {
        color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        icon: CheckCircle2,
        bgGradient: 'from-emerald-400/20 to-green-400/20',
        iconBg: 'from-emerald-500 to-green-500'
      },
      failed: {
        color: 'bg-red-50 text-red-700 border-red-200',
        icon: XCircle,
        bgGradient: 'from-red-400/20 to-rose-400/20',
        iconBg: 'from-red-500 to-rose-500'
      }
    };
    return configs[job.status] || configs.pending;
  }, [job.status]);

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInHours = (now - date) / (1000 * 60 * 60);
    
    if (diffInHours < 1) {
      const minutes = Math.floor(diffInHours * 60);
      return `${minutes}m ago`;
    } else if (diffInHours < 24) {
      return `${Math.floor(diffInHours)}h ago`;
    }
    
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatElapsedTime = (seconds) => {
    if (seconds < 60) return `${seconds}s`;
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
    return `${Math.floor(seconds / 3600)}h ${Math.floor((seconds % 3600) / 60)}m`;
  };

  const handleDelete = async () => {
    if (window.confirm(`Are you sure you want to delete "${job.pr_title}"?`)) {
      setIsDeleting(true);
      try {
        await onDelete();
        // Success toast is handled in parent component
      } catch (error) {
        toast.error('Failed to delete job');
        setIsDeleting(false);
      }
    }
  };

  const handleViewSummary = () => {
    if (job.status !== 'completed') {
      toast.error('Summary is only available for completed jobs', {
        icon: '📄',
      });
      return;
    }
    onViewSummary();
  };

  const copyWorkflowId = async () => {
    try {
      await navigator.clipboard.writeText(job.workflow_id);
      toast.success('Workflow ID copied!', { duration: 2000 });
    } catch (error) {
      toast.error('Failed to copy ID');
    }
  };

  const StatusIcon = statusConfig.icon;

  return (
    <div className={`
      relative overflow-hidden bg-white/90 backdrop-blur-sm border border-white/60 
      rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-500 group 
      hover:bg-white/95 hover:-translate-y-1 hover:scale-[1.02]
      ${isDeleting ? 'opacity-50 pointer-events-none' : ''}
    `}>
      {/* Background gradient overlay */}
      <div className={`absolute inset-0 bg-gradient-to-br ${statusConfig.bgGradient} opacity-0 group-hover:opacity-100 transition-opacity duration-500`} />
      
      {/* Content */}
      <div className="relative p-6">
        {/* Header */}
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center space-x-3 flex-1 min-w-0">
            <div className={`w-12 h-12 bg-gradient-to-br ${statusConfig.iconBg} rounded-xl flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
              <GitPullRequest className="w-6 h-6 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h3 className="font-semibold text-slate-800 text-lg leading-tight group-hover:text-blue-700 transition-colors truncate pr-2">
                {job.pr_title}
              </h3>
              <div className="flex items-center space-x-2 mt-2">
                <span className={`inline-flex items-center space-x-1.5 px-3 py-1.5 rounded-full text-xs font-medium border ${statusConfig.color} shadow-sm`}>
                  <StatusIcon className="w-4 h-4" />
                  <span className="capitalize">{job.status.replace('_', ' ')}</span>
                </span>
                {job.status === 'in_progress' && (
                  <span className="inline-flex items-center space-x-1 px-2 py-1 bg-blue-100 text-blue-600 rounded-full text-xs font-medium">
                    <Timer className="w-3 h-3" />
                    <span>{formatElapsedTime(timeElapsed)}</span>
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Progress Bar for In Progress */}
        {job.status === 'in_progress' && (
          <div className="mb-4 p-3 bg-blue-50/50 rounded-xl border border-blue-100">
            <div className="flex items-center justify-between text-xs text-blue-700 mb-2 font-medium">
              <span className="flex items-center space-x-1">
                <Zap className="w-3 h-3" />
                <span>AI Agent Processing</span>
              </span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-blue-200 rounded-full h-2.5 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-blue-500 to-indigo-600 h-full rounded-full transition-all duration-1000 ease-out relative overflow-hidden"
                style={{ width: `${progress}%` }}
              >
                {/* Animated shimmer effect */}
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent -skew-x-12 animate-pulse" />
              </div>
            </div>
            <div className="flex items-center justify-between mt-2 text-xs text-blue-600">
              <span>Analyzing code patterns</span>
              <span className="animate-pulse">●●●</span>
            </div>
          </div>
        )}

        {/* Job Details Grid */}
        <div className="grid grid-cols-1 gap-3 mb-6">
          <div className="flex items-center space-x-3 text-slate-600 hover:text-slate-800 transition-colors">
            <User className="w-4 h-4 text-slate-400" />
            <span className="text-sm font-medium">{job.pr_author}</span>
          </div>
          
          <div className="flex items-center space-x-3 text-slate-600 hover:text-slate-800 transition-colors">
            <Hash className="w-4 h-4 text-slate-400" />
            <span className="text-sm">PR #{job.pr_number}</span>
          </div>
          
          <div className="flex items-center space-x-3 text-slate-600 hover:text-slate-800 transition-colors">
            <Calendar className="w-4 h-4 text-slate-400" />
            <span className="text-sm">{formatDate(job.created_at)}</span>
          </div>

          <div className="flex items-center space-x-3">
            <ExternalLink className="w-4 h-4 text-slate-400" />
            <a 
              href={job.pr_url} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm text-blue-600 hover:text-blue-800 hover:underline transition-colors font-medium"
            >
              View on GitHub
            </a>
          </div>
        </div>

        {/* Enhanced Action Buttons */}
        <div className="flex items-center space-x-3">
          <button
            onClick={handleViewSummary}
            disabled={job.status !== 'completed'}
            className={`flex items-center space-x-2 px-4 py-2.5 rounded-xl text-sm font-medium transition-all duration-200 shadow-sm hover:shadow-md ${
              job.status === 'completed' 
                ? 'bg-emerald-500 text-white hover:bg-emerald-600 border border-emerald-600 hover:scale-105' 
                : 'bg-slate-100 text-slate-400 cursor-not-allowed border border-slate-200'
            }`}
          >
            <Eye className="w-4 h-4" />
            <span>Summary</span>
          </button>

          <button
            onClick={handleDelete}
            disabled={isDeleting}
            className="flex items-center space-x-2 px-4 py-2.5 bg-red-500 text-white hover:bg-red-600 border border-red-600 rounded-xl text-sm font-medium transition-all duration-200 shadow-sm hover:shadow-md hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Trash2 className={`w-4 h-4 ${isDeleting ? 'animate-spin' : ''}`} />
            <span>{isDeleting ? 'Deleting...' : 'Delete'}</span>
          </button>
        </div>

        {/* Enhanced Workflow ID Section */}
        <div className="mt-4 pt-4 border-t border-slate-100 opacity-0 group-hover:opacity-100 transition-all duration-300 transform translate-y-2 group-hover:translate-y-0">
          <div className="flex items-center justify-between">
            <p className="text-xs text-slate-500 font-mono truncate pr-2">
              {job.workflow_id}
            </p>
            <button
              onClick={copyWorkflowId}
              className="text-slate-400 hover:text-slate-600 transition-colors p-1 rounded hover:bg-slate-100"
              title="Copy Workflow ID"
            >
              <Copy className="w-3 h-3" />
            </button>
          </div>
        </div>

        {/* Status indicator for failed jobs */}
        {job.status === 'failed' && (
          <div className="mt-3 p-2 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-red-500" />
            <span className="text-xs text-red-700 font-medium">Review failed - check logs</span>
          </div>
        )}
      </div>

      {/* Loading overlay for deleting state */}
      {isDeleting && (
        <div className="absolute inset-0 bg-white/80 flex items-center justify-center">
          <div className="flex items-center space-x-2 text-slate-600">
            <div className="w-4 h-4 border-2 border-slate-300 border-t-slate-600 rounded-full animate-spin" />
            <span className="text-sm">Deleting...</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobCard;