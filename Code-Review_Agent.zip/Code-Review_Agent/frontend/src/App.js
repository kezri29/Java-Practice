// import React, { useState, useEffect } from 'react';
// import { Toaster } from 'react-hot-toast';
// import JobDashboard from './components/JobDashboard';
// import SummaryModal from './components/SummaryModal';
// import api from './services/api';

// function App() {
//   const [jobs, setJobs] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [selectedJob, setSelectedJob] = useState(null);
//   const [showSummary, setShowSummary] = useState(false);

//   // Fetch all jobs on component mount
//   useEffect(() => {
//     fetchJobs();
    
//     // Set up polling for real-time updates
//     const interval = setInterval(() => {
//       fetchJobsStatus();
//     }, 3000); // Poll every 3 seconds

//     return () => clearInterval(interval);
//   }, []);
//   // useEffect(() => {
//   // fetchJobs(); // Only runs once when component mounts
//   // }, []);


//   const fetchJobs = async () => {
//     try {
//       setLoading(true);
//       const data = await api.getJobs();
//       setJobs(data.jobs || []);
//     } catch (error) {
//       console.error('Error fetching jobs:', error);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const fetchJobsStatus = async () => {
//     try {
//       const data = await api.getJobsStatus();
//       if (data.jobs_status) {
//         setJobs(prevJobs => 
//           prevJobs.map(job => ({
//             ...job,
//             status: data.jobs_status[job.workflow_id]?.status || job.status
//           }))
//         );
//       }
//     } catch (error) {
//       console.error('Error fetching job status:', error);
//     }
//   };

//   const handleDeleteJob = async (workflowId) => {
//     try {
//       await api.deleteJob(workflowId);
//       setJobs(prevJobs => prevJobs.filter(job => job.workflow_id !== workflowId));
//     } catch (error) {
//       console.error('Error deleting job:', error);
//     }
//   };

//   const handleViewSummary = async (job) => {
//     setSelectedJob(job);
//     setShowSummary(true);
//   };

//   return (
//     <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100">
//       <Toaster 
//         position="top-right" 
//         toastOptions={{
//           duration: 4000,
//           style: {
//             background: '#1e293b',
//             color: '#f8fafc',
//             border: '1px solid #334155',
//             borderRadius: '12px',
//             fontSize: '14px',
//             padding: '12px 16px',
//           },
//         }}
//       />
      
//       <div className="container mx-auto px-6 py-8">
//         <div className="text-center mb-12">
//           <h1 className="text-5xl font-bold bg-gradient-to-r from-slate-800 via-blue-800 to-indigo-800 bg-clip-text text-transparent mb-4">
//             PR Code Review Agent
//           </h1>
//           <p className="text-lg text-slate-600 max-w-2xl mx-auto">
//             Monitor and manage your pull request code reviews with intelligent analysis and automated feedback
//           </p>
//         </div>

//         <JobDashboard 
//           jobs={jobs}
//           loading={loading}
//           onDeleteJob={handleDeleteJob}
//           onViewSummary={handleViewSummary}
//           onRefresh={fetchJobs}
//         />

//         {showSummary && selectedJob && (
//           <SummaryModal
//             job={selectedJob}
//             isOpen={showSummary}
//             onClose={() => {
//               setShowSummary(false);
//               setSelectedJob(null);
//             }}
//           />
//         )}
//       </div>
//     </div>
//   );
// }

// export default App;

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import JobDashboard from './components/JobDashboard';
import SummaryModal from './components/SummaryModal';
import ConnectionStatus from './components/ConnectionStatus';
import api from './services/api';

// Custom hook for smart polling
const useSmartPolling = (fetchFn, options = {}) => {
  const {
    interval = 3000,
    maxInterval = 30000,
    backoffMultiplier = 1.5,
    enabled = true
  } = options;

  const [currentInterval, setCurrentInterval] = useState(interval);
  const intervalRef = useRef(null);
  const lastUpdateRef = useRef(null);

  const startPolling = useCallback(() => {
    if (!enabled) return;

    const poll = async () => {
      try {
        const hasChanges = await fetchFn(lastUpdateRef.current);
        
        if (hasChanges) {
          // Reset interval on activity
          setCurrentInterval(interval);
          lastUpdateRef.current = new Date().toISOString();
        } else {
          // Gradually increase interval when no changes
          setCurrentInterval(prev => Math.min(prev * backoffMultiplier, maxInterval));
        }
      } catch (error) {
        console.warn('Polling error:', error);
        // Increase interval on errors
        setCurrentInterval(prev => Math.min(prev * 2, maxInterval));
      }
    };

    poll(); // Initial call
    intervalRef.current = setInterval(poll, currentInterval);
  }, [fetchFn, enabled, interval, maxInterval, backoffMultiplier, currentInterval]);

  const stopPolling = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  }, []);

  useEffect(() => {
    startPolling();
    return stopPolling;
  }, [startPolling, stopPolling]);

  useEffect(() => {
    // Restart polling when interval changes
    stopPolling();
    if (enabled) {
      setTimeout(startPolling, 100);
    }
  }, [currentInterval, enabled, startPolling, stopPolling]);

  return { currentInterval, stopPolling, startPolling };
};

// Custom hook for connection monitoring
const useConnectionMonitor = () => {
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [apiHealthy, setApiHealthy] = useState(true);

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Periodic health check
    const healthCheckInterval = setInterval(async () => {
      const health = await api.healthCheck();
      setApiHealthy(health.healthy);
    }, 30000);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(healthCheckInterval);
    };
  }, []);

  return { isOnline, apiHealthy };
};

function App() {
  // Core state
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Modal state
  const [selectedJob, setSelectedJob] = useState(null);
  const [showSummary, setShowSummary] = useState(false);
  
  // UI state
  const [refreshing, setRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState(null);

  // Connection monitoring
  const { isOnline, apiHealthy } = useConnectionMonitor();

  // Enhanced job fetching with error handling
  const fetchJobs = useCallback(async (showLoadingSpinner = true) => {
    try {
      if (showLoadingSpinner) setLoading(true);
      setError(null);
      
      const data = await api.getJobs();
      setJobs(data.jobs);
      setLastRefresh(new Date());
      
      // Show success toast only on manual refresh
      if (!showLoadingSpinner) {
        toast.success(`Refreshed ${data.jobs.length} jobs`);
      }
      
      return data.jobs.length > 0;
    } catch (err) {
      console.error('Error fetching jobs:', err);
      setError(err.message);
      
      if (!showLoadingSpinner) {
        toast.error(`Failed to refresh: ${err.message}`);
      }
      
      return false;
    } finally {
      setLoading(false);
    }
  }, []);

  // Smart status polling
  const fetchJobsStatus = useCallback(async (lastUpdate) => {
    try {
      const data = await api.getJobsStatus(lastUpdate);
      
      if (data.has_changes && data.jobs_status) {
        let hasUpdates = false;
        
        setJobs(prevJobs => {
          const updatedJobs = prevJobs.map(job => {
            const newStatus = data.jobs_status[job.workflow_id]?.status;
            if (newStatus && newStatus !== job.status) {
              hasUpdates = true;
              
              // Show status change notification
              if (newStatus === 'completed') {
                toast.success(`${job.pr_title} completed!`, { duration: 5000 });
              } else if (newStatus === 'failed') {
                toast.error(`${job.pr_title} failed`, { duration: 5000 });  
              }
              
              return { ...job, status: newStatus };
            }
            return job;
          });
          
          return updatedJobs;
        });
        
        return hasUpdates;
      }
      
      return false;
    } catch (error) {
      console.warn('Status polling failed:', error);
      return false;
    }
  }, []);

  // Initialize smart polling
  const { currentInterval } = useSmartPolling(
    fetchJobsStatus,
    { 
      enabled: isOnline && apiHealthy && jobs.length > 0,
      interval: 2000,
      maxInterval: 15000 
    }
  );

  // Initial data load
  useEffect(() => {
    fetchJobs(true);
  }, [fetchJobs]);

  // Manual refresh handler
  const handleRefresh = useCallback(async () => {
    setRefreshing(true);
    await fetchJobs(false);
    setRefreshing(false);
  }, [fetchJobs]);

  // Enhanced delete handler with optimistic updates
  const handleDeleteJob = useCallback(async (workflowId) => {
    // Find the job to delete
    const jobToDelete = jobs.find(job => job.workflow_id === workflowId);
    if (!jobToDelete) return;

    // Optimistic update
    setJobs(prevJobs => prevJobs.filter(job => job.workflow_id !== workflowId));
    
    try {
      await api.deleteJob(workflowId);
      toast.success(`Deleted "${jobToDelete.pr_title}"`);
    } catch (error) {
      // Revert optimistic update on error
      setJobs(prevJobs => [...prevJobs, jobToDelete].sort((a, b) => 
        new Date(b.created_at) - new Date(a.created_at)
      ));
      
      toast.error(`Failed to delete: ${error.message}`);
      console.error('Error deleting job:', error);
    }
  }, [jobs]);

  // Summary modal handlers
  const handleViewSummary = useCallback((job) => {
    setSelectedJob(job);
    setShowSummary(true);
  }, []);

  const handleCloseSummary = useCallback(() => {
    setShowSummary(false);
    setSelectedJob(null);
  }, []);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key) {
          case 'r':
            e.preventDefault();
            handleRefresh();
            break;
          case 'Escape':
            if (showSummary) {
              handleCloseSummary();
            }
            break;
          default:
            break;
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [handleRefresh, showSummary, handleCloseSummary]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-100 relative">
      {/* Enhanced toast notifications */}
      <Toaster 
        position="top-right" 
        containerStyle={{ top: 20 }}
        toastOptions={{
          duration: 4000,
          style: {
            background: 'rgba(15, 23, 42, 0.95)',
            color: '#f8fafc',
            border: '1px solid rgba(51, 65, 85, 0.8)',
            borderRadius: '12px',
            fontSize: '14px',
            padding: '12px 16px',
            backdropFilter: 'blur(8px)',
            boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)',
          },
          success: {
            iconTheme: {
              primary: '#10b981',
              secondary: '#f8fafc',
            },
          },
          error: {
            iconTheme: {
              primary: '#ef4444',
              secondary: '#f8fafc',
            },
          },
        }}
      />
      
      {/* Connection status indicator */}
      <ConnectionStatus 
        isOnline={isOnline} 
        apiHealthy={apiHealthy} 
        pollingInterval={currentInterval}
      />
      
      <div className="container mx-auto px-6 py-8">
        {/* Enhanced header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl mb-6 shadow-lg">
            <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </div>
          
          <h1 className="text-5xl font-bold bg-gradient-to-r from-slate-800 via-blue-800 to-indigo-800 bg-clip-text text-transparent mb-4">
            PR Code Review Agent
          </h1>
          
          <p className="text-lg text-slate-600 max-w-2xl mx-auto mb-6">
            Monitor and manage your pull request code reviews with intelligent analysis and automated feedback
          </p>
          
          {lastRefresh && (
            <p className="text-sm text-slate-500">
              Last updated: {lastRefresh.toLocaleTimeString()}
              {currentInterval > 3000 && (
                <span className="ml-2 text-amber-600">
                  • Polling slowed due to inactivity
                </span>
              )}
            </p>
          )}
        </div>

        {/* Error state */}
        {error && (
          <div className="mb-8 p-4 bg-red-50 border border-red-200 rounded-xl">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <svg className="w-5 h-5 text-red-500" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
                <span className="text-red-700 font-medium">Connection Error</span>
              </div>
              <button
                onClick={handleRefresh}
                className="text-red-600 hover:text-red-800 text-sm font-medium"
                disabled={refreshing}
              >
                {refreshing ? 'Retrying...' : 'Retry'}
              </button>
            </div>
            <p className="text-red-600 text-sm mt-1">{error}</p>
          </div>
        )}

        {/* Main dashboard */}
        <JobDashboard 
          jobs={jobs}
          loading={loading}
          refreshing={refreshing}
          onDeleteJob={handleDeleteJob}
          onViewSummary={handleViewSummary}
          onRefresh={handleRefresh}
          pollingInterval={currentInterval}
        />

        {/* Enhanced summary modal */}
        {showSummary && selectedJob && (
          <SummaryModal
            job={selectedJob}
            isOpen={showSummary}
            onClose={handleCloseSummary}
          />
        )}
      </div>
    </div>
  );
}

export default App;