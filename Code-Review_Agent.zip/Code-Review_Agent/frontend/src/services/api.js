// import axios from 'axios';

// const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:2000';

// const api = axios.create({
//   baseURL: API_BASE_URL,
//   timeout: 10000,
//   headers: {
//     'Content-Type': 'application/json',
//   },
// });

// // Request interceptor for logging
// api.interceptors.request.use(
//   (config) => {
//     console.log(`Making ${config.method.toUpperCase()} request to: ${config.url}`);
//     return config;
//   },
//   (error) => {
//     return Promise.reject(error);
//   }
// );

// // Response interceptor for error handling
// api.interceptors.response.use(
//   (response) => {
//     return response.data;
//   },
//   (error) => {
//     console.error('API Error:', error.response?.data || error.message);
    
//     if (error.response?.status === 404) {
//       throw new Error('Resource not found');
//     } else if (error.response?.status >= 500) {
//       throw new Error('Server error occurred');
//     } else if (error.response?.data?.message) {
//       throw new Error(error.response.data.message);
//     } else {
//       throw new Error(error.message || 'An unexpected error occurred');
//     }
//   }
// );

// // API methods
// const apiService = {
//   // Get all jobs
//   getJobs: async () => {
//     return await api.get('/api/jobs');
//   },

//   // Get jobs status for real-time updates
//   getJobsStatus: async () => {
//     return await api.get('/api/jobs/status');
//   },

//   // Delete a specific job
//   deleteJob: async (workflowId) => {
//     return await api.delete(`/api/jobs/${workflowId}`);
//   },

//   // Get job summary
//   getJobSummary: async (workflowId) => {
//     return await api.get(`/api/jobs/${workflowId}/summary`);
//   },
// };

// export default apiService;

import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:2000';

// Create axios instance with better configuration
const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 15000, // Increased timeout
  headers: {
    'Content-Type': 'application/json',
  },
});

// Enhanced request interceptor
api.interceptors.request.use(
  (config) => {
    // Only log in development
    if (process.env.NODE_ENV === 'development') {
      console.log(`🚀 ${config.method.toUpperCase()} ${config.url}`);
    }
    return config;
  },
  (error) => {
    console.error('❌ Request Error:', error);
    return Promise.reject(error);
  }
);

// Enhanced response interceptor with better error handling
api.interceptors.response.use(
  (response) => {
    if (process.env.NODE_ENV === 'development') {
      console.log(`✅ Response from ${response.config.url}:`, response.status);
    }
    return response.data;
  },
  (error) => {
    console.error('❌ API Error:', error.response?.data || error.message);
    
    // Handle different error types
    if (error.code === 'ECONNABORTED') {
      throw new Error('Request timeout - please try again');
    } else if (error.response?.status === 404) {
      throw new Error('Resource not found');
    } else if (error.response?.status === 429) {
      throw new Error('Too many requests - please wait a moment');
    } else if (error.response?.status >= 500) {
      throw new Error('Server error - please try again later');
    } else if (error.response?.data?.message) {
      throw new Error(error.response.data.message);
    } else if (!navigator.onLine) {
      throw new Error('No internet connection');
    } else {
      throw new Error(error.message || 'An unexpected error occurred');
    }
  }
);

// Enhanced API service with better async handling
const apiService = {
  // Get all jobs with caching
  getJobs: async (useCache = false) => {
    try {
      const config = useCache ? { 
        headers: { 'Cache-Control': 'max-age=30' } 
      } : {};
      
      const response = await api.get('/api/jobs', config);
      return {
        jobs: response.jobs || [],
        total: response.total || 0,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      console.error('Failed to fetch jobs:', error);
      throw error;
    }
  },

  // Get jobs status with optimized polling
  getJobsStatus: async (lastUpdate = null) => {
    try {
      const params = lastUpdate ? { since: lastUpdate } : {};
      const response = await api.get('/api/jobs/status', { params });
      
      return {
        jobs_status: response.jobs_status || {},
        has_changes: response.has_changes || false,
        timestamp: new Date().toISOString()
      };
    } catch (error) {
      // Don't throw on status check failures to prevent breaking the polling
      console.warn('Status check failed:', error.message);
      return { jobs_status: {}, has_changes: false };
    }
  },

  // Delete job with optimistic updates
  deleteJob: async (workflowId) => {
    try {
      await api.delete(`/api/jobs/${workflowId}`);
      return { success: true, workflowId };
    } catch (error) {
      console.error(`Failed to delete job ${workflowId}:`, error);
      throw error;
    }
  },

  // Get job summary with retry logic
  getJobSummary: async (workflowId, retries = 2) => {
    try {
      const response = await api.get(`/api/jobs/${workflowId}/summary`);
      return {
        summary: response.summary || 'No summary available',
        generated_at: response.generated_at,
        word_count: response.word_count || 0
      };
    } catch (error) {
      if (retries > 0 && error.message.includes('timeout')) {
        console.log(`Retrying summary fetch for ${workflowId}...`);
        await new Promise(resolve => setTimeout(resolve, 1000));
        return apiService.getJobSummary(workflowId, retries - 1);
      }
      throw error;
    }
  },

  // Health check for connection monitoring
  healthCheck: async () => {
    try {
      const response = await api.get('/health', { timeout: 3000 });
      return { healthy: true, ...response };
    } catch (error) {
      return { healthy: false, error: error.message };
    }
  },

  // Batch operations
  batchDeleteJobs: async (workflowIds) => {
    try {
      const response = await api.post('/api/jobs/batch-delete', { 
        workflow_ids: workflowIds 
      });
      return response;
    } catch (error) {
      console.error('Batch delete failed:', error);
      throw error;
    }
  }
};

// Export individual methods for easier testing
export const { 
  getJobs, 
  getJobsStatus, 
  deleteJob, 
  getJobSummary, 
  healthCheck,
  batchDeleteJobs 
} = apiService;

export default apiService;